#include "Dictionary.h"
using namespace std;
/*
void Dictionary:: read_dictionary(string file_name)
{
    ifstream dictionary_file;
    string word;
    
    dictionary_file.open(file_name);
    
    while (dictionary_file >> word)
    {
        word = make_lower_case(word);
        dictionary.insert(word);
    }
    
    dictionary_file.close();
    
}

string Dictionary:: make_lower_case(string word)
{
    for (unsigned int i = 0; i < word.size(); i++)
    {
        if (isupper(word[i]))
        {
            word[i] = tolower(word[i]);
        }
    }
    return word;
}

void Dictionary:: print_dictionary()
{
    set<string>::iterator iter;
     
    for (iter = dictionary.begin(); iter != dictionary.end(); iter++)
    {
        cout << (*iter) << endl; 
    }
}*/