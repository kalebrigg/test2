#include "Boggle.h"
using namespace std;

Boggle :: Boggle ()
{
    
}

void Boggle:: read_dictionary(string file_name)
{
    ifstream dictionary_file;
    string word;
    
    dictionary_file.open(file_name);
    
    while (dictionary_file >> word)
    {
        word = make_lower_case(word);
        dictionary.insert(word);
    }
    
    dictionary_file.close();
    
}

string Boggle:: make_lower_case(string word)
{
    for (unsigned int i = 0; i < word.size(); i++)
    {
        if (isupper(word[i]))
        {
            word[i] = tolower(word[i]);
        }
    }
    return word;
}

void Boggle:: print_dictionary()
{
    set<string>::iterator iter;
     
    for (iter = dictionary.begin(); iter != dictionary.end(); iter++)
    {
        cout << (*iter) << endl; 
    }
}

void Boggle:: create_board(string file_name)
{
    string line;
    string tile; 
    //int sqrt_size = 0; 
    vector<string> board_tiles;
    
    ifstream board_file;
    board_file.open(file_name);
    
     while(board_file >> tile)
     {
         for (unsigned int i = 0; i < tile.size(); i++)
         {
             tile[i] = tolower(tile[i]);
         }
         board_tiles.push_back(tile); 
     }
     
    sqrt_size = check_sqrt(board_tiles);
    
    for ( int y = 0; y < sqrt_size; y++)
    {
        vector<string> line; 
        for ( int x = 0; x < sqrt_size; x++)
        {
            line.push_back(board_tiles[0]);
            board_tiles.erase(board_tiles.begin());
        }
        final_board.push_back(line);
    }
   
   /*
   ///output board 
    for (unsigned int i = 0; i < final_board.size(); i++)
    {
        for (unsigned int j = 0; j < final_board[i].size(); j++)
        {
            cout << final_board[i][j] << " "; 
        }
        cout << endl; 
    }
    */
   
}

void Boggle:: output(string file_name)
{
    ofstream out_file;
    out_file.open(file_name);
    
    for (unsigned int i = 0; i < final_board.size(); i++)
    {
        for (unsigned int j = 0; j < final_board[i].size(); j++)
        {
            out_file << final_board[i][j] << " "; 
        }
        out_file << endl; 
    }
    out_file << endl; 
   
    set<string>::iterator iter;
     
    for (iter = found_words.begin(); iter != found_words.end(); iter++)
    {
        out_file << (*iter) << endl; 
    }
    
    out_file.close();
}

void Boggle:: recursive_method( int i, int j, string prefix, vector<vector<bool>> visited_board) //needs i and j to know position, current word, places visited )
{

    if (!(check_dimensions( i,  j, visited_board)))
    {
        return; 
    }

    /*
    if ( i < 0 || j < 0 || i >= sqrt_size || j >= sqrt_size ) //invalid position on the grid 
    {
        return; 
    }
    
    if ( visited_board[i][j] == true) //visited already
    {
        return; 
    }
    */
    
    visited_board[i][j] = true; 
    
    
   // is_prefix( i, j, prefix);
    
    prefix += final_board[i][j];
    //cout << "board string: " << final_board[i][j] << endl;
    //cout << " prefix: " << prefix << " size of prefix: " << prefix.size() << endl; 
    
    
    
    set <string> ::iterator it = dictionary.lower_bound(prefix);
    
    //check_iterator(prefix, it);
     
     
    
    if ( it == dictionary.end() )//string is not a prefix of a word in the dictionary
    {
        //cout << "not in dictionary" <<endl;  // WORKING 
        return;
    }
    
    string s = *it;
    //cout << "s string: " << s << " size of s: " << s.size() << endl; 
    
       
    if(s.substr(0, prefix.size()) == prefix)
    {
       //cout << "enter substring" << endl; 
       
       if( prefix.size() >= 4 && s == prefix )
       {
          // cout << "insert word into found_words set" << endl; 
           found_words.insert(prefix);
            
       }
    }
    else
    {
        return; 
    }
    
    
    for( int row = i - 1; row <= i + 1; row++)
    {
        for( int col = j - 1; col <= j + 1; col ++)
        {
            //count ++; 
            //cout << count<< endl; 
            recursive_method( row, col, prefix, visited_board);
            
            
        }
    }
    
}

void Boggle:: start_recursive()
{
    vector<vector<bool>> visited_board;

    for ( int y = 0; y < sqrt_size; y++)
    {
        vector<bool> line; 
        for ( int x = 0; x < sqrt_size; x++)
        {
           line.push_back(false);
        }
        
       visited_board.push_back(line);
    }
     
    string prefix = ""; 
    
    for (unsigned int i = 0; i < final_board.size(); i++)
    {
        for (unsigned int j = 0; j < final_board[i].size(); j++)
        {
            recursive_method( i, j, prefix, visited_board);
        }
    }
}

int Boggle:: check_sqrt(vector<string>board_tiles)
{
    int n = sqrt(board_tiles.size());
    return n; 
}

void Boggle:: is_prefix(int i, int j, string prefix)
{
    prefix += final_board[i][j];
    //cout << "board string: " << final_board[i][j] << endl;
    //cout << " prefix: " << prefix << " size of prefix: " << prefix.size() << endl; 
    
    set <string> ::iterator it = dictionary.lower_bound(prefix);
     
    
    if ( it == dictionary.end() )//string is not a prefix of a word in the dictionary
    {
        //cout << "not in dictionary" <<endl;  // WORKING 
        return;
    }
    string s = *it;
    //cout << "s string: " << s << " size of s: " << s.size() << endl; 
    
       
    if(s.substr(0, prefix.size()) == prefix)
    {
       //cout << "enter substring" << endl; 
       
       if( s == prefix )
       {
          // cout << "insert word into found_words set" << endl; 
           found_words.insert(prefix);
            
       }
    }
    
    else
    {
        return; 
    }
    
}

bool Boggle::check_dimensions(int i, int j, vector<vector<bool>> visited_board)
{
    if ( i < 0 || j < 0 || i >= sqrt_size || j >= sqrt_size ) //invalid position on the grid 
    {
        return false; 
    }
    
    if ( visited_board[i][j] == true) //visited already
    {
        return false; 
    }
    else
    {
        return true; 
    }
}

void Boggle:: check_iterator(string prefix, set <string> ::iterator it)
{
    //set <string> ::iterator it = dictionary.lower_bound(prefix);
     
    
    if ( it == dictionary.end() )//string is not a prefix of a word in the dictionary
    {
        //cout << "not in dictionary" <<endl;  // WORKING 
        return;
    }
}