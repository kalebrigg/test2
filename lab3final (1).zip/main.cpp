
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <stdio.h>
#include <ctype.h>
#include <map>
#include <set>
#include "Dictionary.h"
#include "Board.h"
#include "Boggle.h"
 
using namespace std;

int main(int argc,  char* argv[])
{
    Boggle b; 
    b.read_dictionary(argv[1]);
   // b.print_dictionary();
    b.create_board(argv[2]);
    b.start_recursive(); 
    b.output(argv[3]);
    
   
return 0;
}