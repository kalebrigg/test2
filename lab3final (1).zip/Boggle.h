#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <set>
#include <map>
#include <sstream>


using namespace std;

class Boggle
{
    private:
        vector<vector<string>> final_board;
        set <string> dictionary;
        set <string> found_words; 
        
        int sqrt_size;
      
    public:
        Boggle();
      
        void create_board(string file_name);
        int check_sqrt( vector<string>board_tiles ); 
        
        void read_dictionary(string file_name);
        string make_lower_case(string word);
        void print_dictionary();
  
        void output(string file_name); 
        void recursive_method(int i, int j, string prefix, vector<vector<bool>> visited_board);
        void start_recursive(); 
        void is_prefix(int i, int j, string prefix);
        bool check_dimensions(int i, int j, vector<vector<bool>> visited_board);
        void check_iterator(string prefix, set <string> ::iterator it);
};