#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <set>
#include <map>
#include <sstream>


using namespace std;

class Board
{
    private:
        vector<vector<string>> final_board;

      
      
    public:
        Board();
        
        void create_board(string file_name);
        int check_sqrt( vector<string>board_tiles ); 
  
};


