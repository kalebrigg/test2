#include "Board.h"
using namespace std;

/*
Board :: Board ()
{
    
}

void Board:: create_board(string file_name)
{
    string line;
    string tile; 
    int sqrt_size = 0; 
    vector<string> board_tiles;
    
    ifstream board_file;
    board_file.open(file_name);
    
    
    while (getline(board_file, line))
    {
        stringstream ss(line);
        while ( ss >> tile)
        {
            for (unsigned int i = 0; i < tile.size(); i++)
            {
                tile[i] = tolower(tile[i]);
                
            }
            board_tiles.push_back(tile);
        }
    }
       //USE THIS TO TEST TO SEE IF BOARD TILES ARE READING CORRECTLY 
    for ( auto item : board_tiles)
    {
        cout << item << endl; 
    }
     
     while(board_file >> tile)
     {
         for (unsigned int i = 0; i < tile.size(); i++)
         {
             tile[i] = tolower(tile[i]);
         }
         board_tiles.push_back(tile); 
     }
     
    sqrt_size = sqrt(board_tiles.size());
    
    
    for ( int y = 0; y < sqrt_size; y++)
    {
        vector<string> line; 
        for ( int x = 0; x < sqrt_size; x++)
        {
            line.push_back(board_tiles[0]);
            board_tiles.erase(board_tiles.begin());
        }
        final_board.push_back(line);
    }
   
   
   ///output board 
    for (unsigned int i = 0; i < final_board.size(); i++)
    {
        for (unsigned int j = 0; j < final_board[i].size(); j++)
        {
            cout << final_board[i][j] << " "; 
        }
        cout << endl; 
    }
   
   
   
   
}


int Board :: check_sqrt( vector<string>board_tiles ) 
{
    int n = sqrt(board_tiles.size());
    return n;
    cout << n; 
}
*/