#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <set>
#include <map>
#include <sstream>

using namespace std;

class Dictionary
{
    private:
      set <string> dictionary;
      
    public:
        void read_dictionary(string file_name);
        string make_lower_case(string word);
        void print_dictionary();
  
};


