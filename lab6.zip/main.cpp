/*#include <iostream>
#include <string>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <stdio.h>
#include <ctype.h>*/
#include "AVL_Tree.h"
//#include "Linked_List.h"
using namespace std;

int main(int argc,  char* argv[])
{
    
    string word;
    string line; 
    string name; 
 //   int index; 
    
   // cout << "start program" << endl; 
    AVLTreeSet<string> A; 
    
//////////////// Reading in input
    ifstream input_file; 
    input_file.open(argv[1]);
    
    ofstream out_file;
    out_file.open(argv[2]);
    
    
    while(getline(input_file, line))
    {
        //cout << "start stringstream" << endl;
        stringstream ss(line);
        while ( ss >> word)
        {
            //cout << endl << "ss word: " << word << endl << endl; 
                    ////////////CLEAR
            if ( word == "clear")
            {
              //  cout << "start clear" << endl;
                A.clear();
                out_file << "clear" << endl;
              //  cout << "clear finished" << endl; 
                
            }   
            
                   /////////////INSERT
            else if ( word == "add" )
            {
                ss >> name; 
                A.add( name);
                out_file << "add" << " " << name << endl;
                
            }
            
                  /////////////PRINT
            else if ( word == "print" )
            {
                out_file << "print" << endl;
                //A.print();
                string print = A.print();
                out_file << print; 
            }
            
                 /////////////FIND
            else if ( word == "find" )
            {   
                string ToF;
                ss >> name; 
                bool is_there = A.find(name); 
                if (is_there == 1)
                {
                     ToF = "true";
                }
                else
                {
                     ToF = "false";
                }
                out_file << "find " << name << " " << ToF << endl;
            }
            
                //////////////REMOVE
            else
            {
                ss >> name;
                A.start_remove(name);
                out_file << "remove" << " " << name << endl;
                    
            }
            
        }
    }
    input_file.close();
    out_file.close(); 
    return 0;
}