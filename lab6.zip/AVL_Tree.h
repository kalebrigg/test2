#include <iostream>
#include <string>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <stdio.h>
#include <ctype.h>
#include <sstream>
#include "Linked_List.h"

using namespace std; 

template <typename ItemType>
class AVLTreeSet
{
private: 
    struct Node 
    {
        ItemType item;
        int height;
        Node* left;
        Node* right;
        
        Node(const ItemType& item)
        {
            this->item = item;
            left = NULL;
            right = NULL;
            height = 1; 
        }
    };
    
    
    Node* root;
    Node* temp;
    Node* curr; 
    Node* parent;
    Node* child; 
    int size = 0; 

public: 
    AVLTreeSet()
    {
        root = NULL; 
        temp = NULL;
        curr = NULL;
        parent = NULL;
        child = NULL; 
        size = 0; 
    }

    ~AVLTreeSet()
    {
        clear(); //calls clear 
    }

    void add(const ItemType& item) 
    {
        add_function(root, item);
    }
    
    void add_function(Node*& n, const ItemType& item)
    {
        if ( n == NULL)
        {
            n = new Node(item);
            size += 1; 
        }
        else if (item < n->item)    //less than = left
        {
            add_function(n->left, item);
        }
        else if (item > n->item)    //gr8r than = right
        {
            add_function(n->right, item);
        }
        else
        {
           return;  //do nothing if duplicate
     
        }
        
        check_height(n);
        balance_tree(n);
        
    }

    void start_remove(const ItemType& item) 
    {
        remove_function(root, item); 
    }
    
    void remove_function(Node*& n, const ItemType& item)
    {
        if ( n == NULL ) // item not in AVL tree 
        {
            return; // do nothing 
        }
        else if (item < n->item) // item passed in is less than the item of N
        {
            remove_function(n->left, item);
        }
        else if (item > n->item) // item passed in is greater than item of N
        {
            remove_function(n->right, item);
        }
        else 
        {
            if (n->left == NULL && n->right == NULL) // no children
            {
                temp = n;
                n = NULL; 
                delete temp; 
                size--;
                
            }
            else if (n->left == NULL) //right child only
            {
                temp = n; 
                n = n->right; 
                delete temp; 
                size--; 
                
            }
            else if (n->right == NULL) // left child only 
            {
                temp = n; 
                n = n->left;
                delete temp; 
                size--;
                
            }
            else //two children
            {
                n->item = find_minimum(n->right);
                remove_function(n->right, n->item);
            }
        }
        
        check_height(n);
        balance_tree(n);
        
    }
    
    ItemType find_minimum(Node* n) 
    {
        if (n->left == NULL)
        {
            return n->item;
        }
        else
        {
            return find_minimum(n->left);
        }
    }
    
    bool find(const ItemType& item) 
    {
        return find_function(root, item);
    }
    
    bool find_function(Node* n, const ItemType& item) 
    {
        if ( n == NULL)
        {
            return false; 
        }
        if (item < n->item)
        {
            return find_function(n->left, item);
        }
        else if (item > n->item)
        {
            return find_function(n->right, item);
        }
        else
        {
            return true; 
        }
    }
    
    
    string print()
    {
        stringstream ss;
        if (root == NULL) 
        {
            return ss.str(); 
        }
        
        Linked_List<Node*> L;
        L.insert(L.get_size(),root);
        int level = -1;
       // int max_size = 8; 
        int nodes_on_line = 0; 
        while (L.get_size() > 0)
        {
            int nodes_on_level = L.get_size(); 
            
            /*
            if ( nodes_on_level == 0 ) 
            {
                return ss.str(); 
            }
            else
            {
                level++;
                nodes_on_line = 0;
            }*/
            
            level++;
            nodes_on_line = 0;
            
            ss << "level " << level << ": ";
            
            while (nodes_on_level > 0)
            {
                Node* n = L.remove_item(0);
               // cout << nodes_on_line;
                
                
                if (nodes_on_line != 0 && nodes_on_line % 8 == 0)
                {
                   
                    ss << endl; 
                    ss << "level " << level << ": ";
                    nodes_on_line = 0; 
                    
                    
                }
               
                ss << n->item << "(" << n->height << ") "; 
                nodes_on_line++;
                
               
                if(n->left != NULL)
                {
                    L.insert(L.get_size(), n->left);
                }
                if(n->right != NULL)
                {
                    L.insert(L.get_size(), n->right);
                }
                
                nodes_on_level--; 
                
                //cout << n->item << "(" << n->height << ") "; 
                //ss << n->item << "(" << n->height << ") "; 

            }
            
            //cout << endl; 
            ss << endl; 
            
        }
        return ss.str(); 
    }
    
    void clear()
    {
        if(size == 0)
        {
            return; 
        }
        while (size > 0)
        {
            start_remove(root->item);
            
        }
    }
    
    void balance_tree(Node*& n)
    {
        int L = 0; 
        int R = 0; 
        
        if ( n == NULL)
        {
            return;
        }
        
        if ( n->right == NULL && n->left == NULL ) //no children, balanced 
        {
            return; 
        }
        if ( n->left != NULL)
        {
            L = n->left->height;
        }
        if ( n->right != NULL)
        {
            R = n->right->height; 
        }
    
        int balance = R - L; 
        //cout << "balance " << balance << endl; 
        if ( balance > 1 )
        {
            checks_left_heavy_child(n);
        }
        else if (balance < - 1 )
        {
            checks_right_heavy_child(n);
        }
        
        
    }
    
    void checks_left_heavy_child(Node*& n)
    {
        if ( get_height(n->right->left) > get_height(n->right->right) )
        {
            right_rotation(n->right);
        }
        
        left_rotation(n); 
        
    }   
    
    void left_rotation(Node*& n)
    {
        temp = n; 
        n = n->right;      
        temp->right = n->left;
        n->left = temp; 
        check_height(temp);
        check_height(n);
    }
    
    void checks_right_heavy_child(Node*& n)
    {
        if ( get_height(n->left->right) > get_height(n->left->left) )
        {
            left_rotation(n->left);
        }
        
        right_rotation(n); 
    }
    void right_rotation(Node*& n)
    {
        temp = n; 
        n = n->left;    
        temp->left = n->right; 
        n->right = temp; 
        check_height(temp);
        check_height(n);
    }
    
    void check_height(Node*& n)
    {
        //5 cases
        if ( n == NULL)
        {
            return; 
        }
        
        //1. if there is only 1 n return 
        if( n->left == NULL && n->right == NULL )
        {
            // already constructed to be height = 1, dont need to do anything
            n->height = 1;
            return; 
        }
        
        //2. if there is only left child n-> height = n->left->height +1
        else if (n->right == NULL && n->left != NULL)
        {
            n->height = n->left->height + 1; 
        }
        
        //3. If there is only right child n->height = n->right->height +1
        else if (n->right != NULL && n->left == NULL)
        {
            n->height = n->right->height + 1; 
        }
        
        //4. if there is both right and left child take the height of both and find the max, n->eight = max +1 
        else
        {
            int max_height = max( n->right->height, n->left->height );
            n->height = max_height + 1; 
        }
        
    }
    
    int get_height(Node* n)
    {
        if ( n != NULL)
        {
            return n->height; 
        }
        return 0; 
    }
    

};

