#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <stdio.h>
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <stdexcept>

#include "LinkedListInterface.h"
using namespace std;

template <typename T>
class LinkedList : public LinkedListInterface<T>
{
public:

    class Node {
    public:
        T value;
        Node *next;
        
        Node(T valor) {
            value = valor;
            next = NULL;
        }
    };

    LinkedList() {
        head = tail = NULL;
        list_size = 0;
    }

    
     void insertHead(T value)
     {
        if ( list_size == 0 )
        {
                Node *n = new Node(value);
                n->next = NULL;
                head = n;
                tail = n; 
                list_size++; 
                return; 
        }
            
         if (!(check_duplicate(value)))
         {
            
         
             Node *n = new Node(value);
             n->next= head;
             head = n;
             list_size++; 
             return; 
         }
         
        
     }
     
     void insertTail(T value)
     {
        if ( list_size == 0 )
        {
                Node *n = new Node(value);
                n->next = NULL;
                head = n;
                tail = n; 
                list_size++; 
                return; 
        }
            
         if (!(check_duplicate(value)))
         {
         
             Node *n = new Node(value);
             tail->next= n;
             tail = n;
             n->next = NULL; 
             list_size++; 
             return; 
         }
         
     }
    
     void insertAfter(T value, T insertionNode)
     {
         if (list_size == 0)
         {
             return; 
         }
         Node *curr;
         curr = head; 
         //T finder = insertionNode; 
         if (!(check_duplicate(value)))
         {
            while( curr->next != NULL )
            {
                if (curr->value == insertionNode ) 
                {
                    Node *n = new Node(value);
                    n->next = curr->next;
                    curr->next= n;
                    list_size++; 
                    return; 
               
                }
             
             curr = curr->next; 
            }
            if (curr == tail && curr->value == insertionNode)//last position
            {
                Node *n = new Node(value);
                tail->next= n;
                n->next = NULL;
                tail = n;
                list_size++; 
                return; 
             }
         }
         
     }
     
    bool check_duplicate(T value)
    {
        Node *curr = head; 
        while (curr->value != value )
        {
            if (curr->next == NULL)
            {
                return false; 
            }
            curr = curr->next;
        }
        return true; 
    }
     
      void remove(T value)
      {
          Node *curr; 
          Node *prev; 
          curr = head; 
          prev = NULL; 
         
         if ( list_size == 0)
         {
             return; 
         }
         if (check_duplicate(value))
         {
             while (curr->next != NULL )
             {
                  if (curr->value == value)
                  {
                      if ( head == curr)
                      {
                          head = head->next; 
                          curr->next = NULL;
                          delete curr; 
                          list_size --; 
                          return; 
                      }
                      else
                      {
                          prev->next = curr->next;
                          curr->next = NULL; 
                          delete curr;
                          list_size--; 
                          return; 
                      }
                  }
                  prev = curr; 
                  curr = curr->next; 
             }
             if ( list_size == 1)
                prev = curr; 
             
             tail = prev;
             tail->next = NULL;
          
             delete curr; 
             
             list_size --;
             
             if (list_size == 0)
             {
                 head = NULL; 
                 tail = NULL; 
             }
                
             return; 
         }
          
          
      }
    
     void clear()
     {
        Node *curr; 
        Node *prev;
        curr = head; 
        
        if (list_size == 0 )
        {
            return; 
        }
        
        while (curr->next != NULL)
        {
            prev = curr;
            curr = curr->next; 
            delete prev; 
        }
        
        delete curr; 
        head = NULL;
        tail = NULL;
        list_size = 0; 
        
     }
    
     T at(int index)
     {
         Node *curr; 
         curr = head; 
         
         if (index >= list_size || index < 0 )
         {
             throw out_of_range("NOT TODAY"); 
         }
         
         for (unsigned int i = 0; i < index ; i++ )
         {
             curr = curr->next; 
         }
         return curr->value; 
     }
   
     int size()
     {
        return list_size;    
     }
     
     string toString()
     {
         stringstream ss; 
         Node *curr = head;
         
         if (list_size == 0)
         {
             return ss.str();
         }
         
         ss << curr->value;
         
         if (list_size == 1)
         {
             return ss.str(); 
         }
         curr = curr->next;
         
         while (curr->next != NULL)
         {
             ss << " " << curr->value;
             curr = curr->next; 
         }
         ss << " " << curr->value; 
         
         return ss.str(); 
         
         
     }
     
     virtual ~LinkedList(void)
     {
         clear(); 
     }
     
     

private:
    Node *head, *tail;
    int list_size;
    
};


#endif





 /*
    void remove(int index) {
        if ((index >= size) || (index < 0)) {
            cout << "Can't remove that dobrain." << endl;
            return;
        }
    
        if (index == 0) {  // we are removing the head
            Node *cur = head;
            head = head->next;
            delete cur;
            if (size == 1)
                tail = NULL;
        }
        else if (index == (size-1)) { // we are removing the tail
            Node *cur = head;
            while (cur->next != tail) {
                cur = cur->next;
            }
            delete tail;
            cur->next = NULL;
            tail = cur;
        }
        else {  // we are removing something in the middle
            Node *prev = head;
            for (int i = 0; i < index-1; i++) {
                prev = prev->next;
            }
            Node *cur = prev->next;
            prev->next = cur->next;
            delete cur;
        }
    
        size --;
    }
    
    
    
    void append(T newVal) {
        if (size == 0) {
            head = tail = new Node(newVal);
            size ++;
            return;
        }
    
        tail->next = new Node(newVal);
        tail = tail->next;
        size ++;
    }
    
    T get(int index) {
        if (index >= size) {
            cout << "This is gonna crash." << endl;
            return NULL;
        }
    
        Node *cur = head;
        for (int i = 0; i < index; i++) {
            cur = cur->next;
        }
        
        return cur->value;
    }
    
    void set(int index, T val) {
        if (index >= size) {
            cout << "You blessed soul." << endl;
            return;
        }

        Node *cur = head;
        for (int i = 0; i < index; i++) {
            cur = cur->next;
        }
        
        cur->value = val;
    }
    
    int size() {
        return size;
    }
    
    void print() {
        cout << "Print list of length: " << size << endl;
        Node *current = head;
    
        while (current != NULL) {
            cout << current->value << " ";
            current = current->next;
        }
        cout << endl;
    }
    */