#include "ExpressionManager.h" 
#include <sstream>
#include <string>
#include <iostream>

using namespace std;

	const string OPEN = "([{";
	const string CLOSE = ")]}"; 
	
	bool is_open(char ch)
	{
		return OPEN.find(ch) != string::npos;
	}
	bool is_close(char ch) 
	{
		return CLOSE.find(ch) != string::npos;
	}
	
	bool is_left_paren(string t)
	{
		for (int i = 0; i < t.size(); i++ )
		{
			if ( t == "(" || t == "[" || t == "{")
			{
				return true; 
			}
			else
			{
				return false; 
			}
		}
	}
	
	bool is_right_paren(string t)
	{
		for (int i = 0; i < t.size(); i++ )
		{
			if ( t == ")" || t == "]" || t == "}")
			{
				return true; 
			}
			else
			{
				return false; 
			}
		}
	}
	
	int get_precedence ( string t)
	{
		switch (t.at(0))
		{
			case ')': 
			case '}':
			case ']':
				return 3; 
					break;
		
			case '(': 
			case '{':
			case '[':
				return 0; 
					break;
			
			case '/': 
			case '%':
			case '*':
				return 2; 
					break;
					
			case '+': 
			case '-':
				return 1; 
					break;
		}
	}
	
	
	
	
	
	
	
	
///////////////////////////////////////////////////////////////////

	const std::string OPERATORS = "+-*/%";
	const std::string OPERATORSP1 = "{[("; 
	const std::string OPERATORSP2 = ")]}";
	const int PRECEDENCE [] = { 1, 1, 2, 2, 2 };
	const int PRECEDENCEP1 [] = { 0, 0, 0 };  
	const int PRECEDENCEP2 [] = { 3, 3, 3 }; 
	
	bool is_operator(string t)
	{
		return OPERATORS.find(t) != std::string::npos; 
	}
	
	bool is_number(string t)
	{
		for (int i = 0; i < t.size(); i++ )
		{
			if (!isdigit(t.at(i)))
			{
				return false;
			}
		}
		return true; 
		
	}
	
	/*
	int eval_op(char op, stack<int>operand_stack)
	{
		if (operand_stack.empty())
			throw Syntax_E
	}
	*/
	
	
///////////////////////////////////////////////////////////////////

	bool ExpressionManager:: isBalanced(string expression)
	{
		
	    stack<char> stack;
        bool balanced = true;
        string::const_iterator iter = expression.begin();
                                              
        while ( balanced && (iter != expression.end())) 
        {
        	char next_ch = *iter;
        	if (is_open(next_ch))
        	{
        		stack.push(next_ch);
        	}
        	else if (is_close(next_ch))
        	{
        		if (stack.empty())
        		{
        			balanced = false;
        		}
        	
        		else
        		{
	        		char top_ch = stack.top(); 
	        		stack.pop();
	        		balanced =
	        			OPEN.find(top_ch) == CLOSE.find(next_ch);
        		}
        	}
        ++iter;	
        }
       return balanced && stack.empty();
	}
       

	string ExpressionManager:: postfixToInfix(string postfixExpression)
	{
	    stack<string> postfixString;
	    string tempToken = "";
	    string push_to_stack = "";
	    stringstream get_input(postfixExpression);
	    
	    while (get_input >> tempToken)
	    {
	    	
	    //	postfixString.pop();
	    	if (is_number(tempToken))
	    	{
	    		postfixString.push(tempToken);
	    	}
	    	else if ( is_operator(tempToken) == false)
	    	{
	    		return "invalid";
	    	}
	    	else
	    	{
	    		if ( postfixString.size() < 2 )
	    		{
	    			return "invalid"; 
	    		}
	    		string temp2 = postfixString.top();
	    		if ( (tempToken == "/" || tempToken == "%") && temp2 == "0")
	    		{
	    			return "invalid"; 
	    		}
	    		
	    		postfixString.pop();
	    		
	    		string temp3 = "( " + postfixString.top() + " " + tempToken + " " + temp2 + " )";
	    		
	    		postfixString.pop();
	    		postfixString.push(temp3);
	    		
	    		
	    		
	    	}
	    }
	    if (postfixString.size() > 1 )
		{
	    	return "invalid"; 
	   	}
	   
	    return postfixString.top(); 
	   
	}

	string ExpressionManager:: postfixEvaluate(string postfixExpression)
	{
		
		stack<int> postfixString;
	    string tempToken = "";
	 
	    stringstream get_input(postfixExpression);
	    
	    while (get_input >> tempToken)
	    {
	    	
	    //	postfixString.pop();
	    	if (is_number(tempToken))
	    	{
	    		postfixString.push(std::stoi(tempToken));
	    	}
	    	else if ( is_operator(tempToken) == false)
	    	{
	    		//return tempToken; 
	    		return "invalid";
	    	}
	    	else
	    	{
	    		if ( postfixString.size() < 2 )
	    		{
	    			return "invalid"; 
	    		}
	    		
	    		int temp2 = postfixString.top();
	    		
	    		if ( (tempToken == "/" || tempToken == "%") && temp2 == 0 )
	    		{
	    			return "invalid"; 
	    		}
	    		
	    		postfixString.pop();
	    		
	    		int temp3; //= "( " + postfixString.top() + " " + tempToken + " " + temp2 + " )";
	    		
	    		switch (tempToken.at(0))
	    		{
	    			case '*': 
	    				temp3 = postfixString.top() * temp2; 
	    				break; 
	    			
	    			case '/':
	    				temp3 = postfixString.top() / temp2;
	    				break; 
	    				
	    			case '+':
	    				temp3 = postfixString.top() + temp2;
	    				break; 
	    				
	    			case '-':
	    				temp3 = postfixString.top() - temp2;
	    				break; 
	    			
	    			case '%':
	    				temp3 = postfixString.top() % temp2;
	    				break; 
	    			
	    		}
	    		
	    		
	    		postfixString.pop();
	    		postfixString.push(temp3);
	    		
	    	
	    	}
	    }
		
		if (postfixString.size() > 1 )
		{
			return "invalid"; 
		}
		
		stringstream end;
		end << postfixString.top();
		string s = end.str();
		return s; 
	}

	string ExpressionManager:: infixToPostfix(string infixExpression)
	{
	    stack<string> postfixString;
	    string tempToken = "";
	    string postfix = ""; 
	    int precedence = 0; 
	    string prevToken = ""; 
		int tokenNumber = 0; 
	    stringstream get_input(infixExpression);
//////////////////////////////////////////////////////////	    
	     stack<char> stack;
        bool balanced = true;
        string::const_iterator iter = infixExpression.begin();
                                              
        while ( balanced && (iter != infixExpression.end())) 
        {
        	char next_ch = *iter;
        	if (is_open(next_ch))
        	{
        		stack.push(next_ch);
        	}
        	else if (is_close(next_ch))
        	{
        		if (stack.empty())
        		{
        			balanced = false;
        			
        		}
        	
        		else
        		{
	        		char top_ch = stack.top(); 
	        		stack.pop();
	        		balanced =
	        			OPEN.find(top_ch) == CLOSE.find(next_ch);
        		}
        	}
        ++iter;	
        }
       
       if (balanced == false)
       {
       	return "invalid"; 
       }
       
       if (stack.empty() == false)
       {
       	return "invalid"; 
       }
	    
/////////////////////////////////////////////////////////////////////////////////////////////	    
	    while (get_input >> tempToken)
	    {
	    	 tokenNumber++;
	    	
	    	if (is_number(tempToken) )
	    	{
	    		
	    		if ( tokenNumber < 2)
	    		{
	    			postfix += tempToken + " ";
	    		}
	    			
	    		else if (is_number(prevToken) || is_right_paren(prevToken) )
	    		{
	    			return "invalid"; 
	    		}
	    		else
	    			postfix += tempToken + " ";
	    	}
	    	else if (is_operator((tempToken)))
	    	{	
	    		
	    		if ( is_operator(prevToken) || is_left_paren(prevToken))
	    		{
	    			return "invalid"; 
	    		}
	    		
	    		
	    		if (postfixString.size() < 1 )
	    		{
	    			postfixString.push(tempToken);
	    		}
	    		
	    		else if ( get_precedence(tempToken) > get_precedence(postfixString.top()) )
	    		{
	    			postfixString.push(tempToken); 
	    		}
	    		else 
	    		{
	    	//		cout << "first enter" << endl; 
	    			while ( (!postfixString.empty() ) && get_precedence(tempToken) <= get_precedence(postfixString.top()) )
	    			{
	    				postfix += postfixString.top() + " "; 
	    				postfixString.pop(); 
	    			}
	    			postfixString.push(tempToken); 
	    		//	cout << "first exit" << endl; 
	    		}
	    		
	    	}
	    	else if ( is_left_paren(tempToken) )
	    	{
	    		/*
	    		if (is_number(prevToken) || is_right_paren(prevToken))
	    		{
	    			return "iinvalid"; 
	    		}
	    		*/
	    		postfixString.push(tempToken); 
	    	}
	    	else if ( is_right_paren(tempToken))
	    	{
	    	
	    		if ( is_left_paren(prevToken) || is_operator(prevToken))
	    		{
	    			return "invalid"; 
	    		}
	    		
	    //		cout << "ffirst enter" << endl; 
	    		while ( (!postfixString.empty() ) && ( !(OPEN.find(postfixString.top()) == CLOSE.find(tempToken)) ) )
	    		{
	    			postfix += postfixString.top() + " "; 
	    			postfixString.pop(); 
	    		}
				
				if (!postfixString.empty())
					postfixString.pop(); 
					
					
		//			cout << "ffirst exit" << endl; 
	    	}
	    	else 
	    	{
	    		return "invalid"; 
	    	}
	    	prevToken = tempToken; 
	    }
	    while (!postfixString.empty())
	    {
	    	postfix += postfixString.top() + " "; 
	    	postfixString.pop(); 
	    }
	    postfix.erase (postfix.size() - 1 ); 
	    return postfix; 
	}
	   



// INVALID:    
/*
right int 
int left 
right left 
left right 
op right 
left op 
op op

end of while set prev token to current token,, top of while reset cur 
*/
/*
	   {
	    stack<string> postfixString;
	    string tempToken = "";
	    string postfix = ""; 
	    int precedence = 0; 
	    string prevToken = ""; 
		int tokenNumber = 0; 
	    stringstream get_input(infixExpression);
//////////////////////////////////////////////////////////	    
	     stack<char> stack;
        bool balanced = true;
        string::const_iterator iter = infixExpression.begin();
                                              
        while ( balanced && (iter != infixExpression.end())) 
        {
        	char next_ch = *iter;
        	if (is_open(next_ch))
        	{
        		stack.push(next_ch);
        	}
        	else if (is_close(next_ch))
        	{
        		if (stack.empty())
        		{
        			balanced = false;
        			
        		}
        	
        		else
        		{
	        		char top_ch = stack.top(); 
	        		stack.pop();
	        		balanced =
	        			OPEN.find(top_ch) == CLOSE.find(next_ch);
        		}
        	}
        ++iter;	
        }
       
       if (balanced == false)
       {
       	return "invalid"; 
       }
       
       if (stack.empty() == false)
       {
       	return "invalid"; 
       }
	    
/////////////////////////////////////////////////////////////////////////////////////////////	    
	    while (get_input >> tempToken)
	    {
	    	 tokenNumber++;
	    	
	    	if (is_number(tempToken) )
	    	{
	    		
	    		if ( tokenNumber < 2)
	    		{
	    			postfix += tempToken + " ";
	    		}
	    			
	    		else if (is_number(prevToken) || is_right_paren(prevToken) )
	    		{
	    			return "invalid"; 
	    		}
	    			
	    	}
	    	else if (is_operator((tempToken)))
	    	{	
	    		
	    		if ( is_operator(prevToken) || is_left_paren(prevToken))
	    		{
	    			return "invalid"; 
	    		}
	    		
	    		
	    		if (postfixString.size() < 1 )
	    		{
	    			postfixString.push(tempToken);
	    		}
	    		
	    		else if ( get_precedence(tempToken) > get_precedence(postfixString.top()) )
	    		{
	    			postfixString.push(tempToken); 
	    		}
	    		else 
	    		{
	    	//		cout << "first enter" << endl; 
	    			while ( (!postfixString.empty() ) && get_precedence(tempToken) <= get_precedence(postfixString.top()) )
	    			{
	    				postfix += postfixString.top() + " "; 
	    				postfixString.pop(); 
	    			}
	    			postfixString.push(tempToken); 
	    		//	cout << "first exit" << endl; 
	    		}
	    		
	    	}
	    	else if ( is_left_paren(tempToken) )
	    	{
	    		
	    		if (is_number(prevToken) || is_right_paren(prevToken))
	    		{
	    			return "iinvalid"; 
	    		}
	    		postfixString.push(tempToken); 
	    	}
	    	else if ( is_right_paren(tempToken))
	    	{
	    	
	    		if ( is_left_paren(prevToken) || is_operator(prevToken))
	    		{
	    			return "invalid"; 
	    		}
	    		
	    //		cout << "ffirst enter" << endl; 
	    		while ( (!postfixString.empty() ) && ( !(OPEN.find(postfixString.top()) == CLOSE.find(tempToken)) ) )
	    		{
	    			postfix += postfixString.top() + " "; 
	    			postfixString.pop(); 
	    		}
				
				if (!postfixString.empty())
					postfixString.pop(); 
					
					
		//			cout << "ffirst exit" << endl; 
	    	}
	    	else 
	    	{
	    		return "invalid"; 
	    	}
	    	prevToken = tempToken; 
	    }
	    while (!postfixString.empty())
	    {
	    	postfix += postfixString.top() + " "; 
	    	postfixString.pop(); 
	    }
	    postfix.erase (postfix.size() - 1 ); 
	    return postfix; 
	}
	    */