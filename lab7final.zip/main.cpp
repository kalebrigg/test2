#include "Hash_Set.h"

using namespace std;

int main(int argc,  char* argv[])
{
    
    string word;
    string line; 
    string name; 
    
    Hash_Set<string> H; 
    
//////////////// Reading in input
    ifstream input_file; 
    input_file.open(argv[1]);
    
    ofstream out_file;
    out_file.open(argv[2]);
    
    
    while(getline(input_file, line))
    {
        //cout << "start stringstream" << endl;
        stringstream ss(line);
        while ( ss >> word)
        {
            //cout << endl << "ss word: " << word << endl << endl; 
                    ////////////CLEAR
            if ( word == "clear")
            {
              //  cout << "start clear" << endl;
                H.clear();
                out_file << "clear" << endl;
              //  cout << "clear finished" << endl; 
                
            }   
            
                   /////////////INSERT
            else if ( word == "add" )
            {
                /*
                while ( ss >> index >> name)
                {
                    L.insert(index, name);
                    out_file << "insert " << index << " " << name << endl;
                }
                */
                ss >> name; 
                H.add(name);
                out_file << "add " << name << endl;
                
            }
            
                  /////////////PRINT
            else if ( word == "print" )
            {
                out_file << "print" << endl;
                string print = H.print();
                out_file << print; 
            }
            
                 /////////////FIND
            else if ( word == "find" )
            {
                /*
                while ( ss >> name )
                {
                    L.find( name );
                    int number = L.find(name); 
                    out_file << "find " << name << " " << number << endl;
                }*/
                string true_false;
                ss >> name; 
               // H.find( name );
                bool is_there = H.find(name); 
                if (is_there == 1)
                {
                     true_false = "true";
                }
                else
                {
                     true_false = "false";
                }
                out_file << "find " << name << " " << true_false << endl;
            }
            
                //////////////REMOVE
            else
            {
                ss >> name;
               // L.remove_item(index); 
                
                //string remove_string =
                H.remove(name);
                out_file << "remove " << name << endl; 
                    
                    
                    //string remove_print = L.remove_item(index); 
                   // out_file << remove_print;
/*
                    string index_name = L.remove_item(index); 
                    if (index_name == "not found")
                    {
                        out_file << "remove " << index  << endl;  
                    } 
                    else 
                    {
                        out_file << "remove " << index << " " << index_name << endl; 
                    }    
                    
                    */
            }
            
        }
    }
    input_file.close();
    out_file.close(); 
    return 0;
}