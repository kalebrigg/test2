#include <iostream>
#include <string>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <stdio.h>
#include <ctype.h>
#include <sstream>

#include "Linked_List.h"

using namespace std;

template <typename T>
class Hash_Set 
{
    private:
    
        int table_size; // how many lists 
        Linked_List<T>* table; //= new Linked_List<T> [table_size];
        int size; //size inside the list
        int capacity; 

    public: 


        Hash_Set()
        {
            //table = new List<T>[table_size];
             table_size = 0;
             size = 0;
             capacity = 0;
             table = NULL;
        }
            
        ~Hash_Set()      //deconstructor
        {
            clear();
        }
                 
        void add(const T& item) 
        {
        
        	
            if ( find(item) )
            {
                return; 
            }
            cout << "Add: " << item << endl; 
                rehash_function();
                
                unsigned index = hash_code(item);
             //   table = table[index];
                table[index].insert(table[index].get_size(), item); 
            
                size++; 
        
        }
        
        
        void remove(const T& item) 
        {
            
            if ( !find(item) ) //not there
            {
                return; 
            }
            else
            {
                
                unsigned index = hash_code(item);
                int find_result = table[index].find(item);
                //table = table[index];
                
                table[index].remove_item(find_result);
                cout << item << " Removed " << endl; 
                size--;
                
                cout << "size after remove:" << size << endl; 
                rehash_function(); 
                
                
            }
                
            
        }
        
        bool find(const T& item) 
        {
            if (table_size == 0)
            {
                return false; 
            }
            
            unsigned index = hash_code(item);
           // table = table[index];
            int ToF = table[index].find(item);
            
            if ( ToF == -1 )
            {
                return false; 
            }
            else
            {
                return true; 
            }
                
            
           // return false;
        }
    
        void clear()
        {
            /*
             go through each list in the array 
             clear list
             delete list
             delete array (can be done in main)
             */
             /*
             if(size == 0 || table_size == 0)
             {
                 return; 
             }
             while (size > 0)
             {
                 for (int i = 0; i < table_size; i++)
                 {
                    while( table[i].get_size() != 0 ) 
                    {
                       table[i].clear();  
                    }
                     
                 }
             }
             
             delete[] table;
             table = NULL; 
             return; 
             */
             
             if(table != NULL)
             {
                delete[] table;
                table = NULL;
                size = 0; 
                table_size = 0; 
                
             }
             
             
             
        }
        
        string print()
        {
           
            T item;
            stringstream ss; 
            //string s; 
            cout << "size: " << size << endl; 
            
            for( int i = 0; i < table_size; i++ )
                {
                    ss << "hash " << i << ": ";
                   
                    ss << table[i].print(i);
                    ss << endl; 
                    cout << endl; 
                }
                return ss.str(); 
            
            
            /*if (size != 0)
            {
                
                 return ss.str();
            }
            else
            {
               return ss.str(); 
            }*/
            
                
            
        }
        
        unsigned hash_code( const string& s ) 
        {
            /*
                initialize hash_index to zero
                (use 'unsigned' as the type for 'hash_index')

                for each character c in the string
                    multiply hash_index by 31
                    add the ASCII code for c to hash_index
                end for

                mod hash_index with the hash table array size
            */
            
            unsigned hash_index = 0; 
            
            for ( unsigned int i = 0; i < s.size(); i++)
            {
                hash_index = hash_index * 31 + (unsigned int) s[i];
            }
            
            
            return hash_index = hash_index % table_size; 
        }
        
        void rehash_grow()
        {
            T item; 
            
            Linked_List<T>* temp = table; 
            int temp_table_size = table_size; 
            table_size = table_size * 2 + 1;
            table = new Linked_List<T> [table_size];
            cout << "(grow)table size" << table_size << endl; 
            
            for (int i = 0; i < temp_table_size; i++) // goes through each list/bucket
            {
                //cout << "i: " << i << endl; 
                while( temp[i].get_size() != 0) //goes through each item of list/bucket
                {
                  //  cout << "temp[i].get_size(): " << temp[i].get_size() << endl; 
                    item = temp[i].remove_item(0); //very front 
                  //  cout << "enter looop" << endl; 
                    unsigned index = hash_code(item); 
                    
                    table[index].insert(table[index].get_size(), item); 
                    
                }
                
            }
            
            delete[] temp; 
            return; 
        }
        void rehash_shrink()
        {
            T item; 
            
            Linked_List<T>* temp = table;
             int temp_table_size = table_size; 
             table_size = table_size / 2;
             table = new Linked_List<T> [table_size];
             cout << "(shrink)table size" << table_size << endl; 
            
            for (int i = 0; i < temp_table_size; i++) // goes through each list/bucket
            {
                //cout << "i: " << i << endl; 
                while( temp[i].get_size() != 0) //goes through each item of list/bucket
                {
                  //  cout << "temp[i].get_size(): " << temp[i].get_size() << endl; 
                    item = temp[i].remove_item(0); //very front 
                  //  cout << "enter looop" << endl; 
                    unsigned index = hash_code(item); 
                
                    table[index].insert(table[index].get_size(), item); 
                    
                }
                
            }
            
            delete[] temp;
            return; 
        }
        
        void rehash_function()
        {
            
            
            if (table == NULL)
            {
                table_size = 1; 
                table = new Linked_List<T> [table_size];
                return; 
            }
            
            if (table_size == size) //grow
            {
                rehash_grow(); 
            }
	                
            else if (size == table_size/2) //shrink 
            {
                rehash_shrink();
            }
	        
        }
        
        
        
};










