#include "BST.h"
#include "NodeInterface.h"

    
    NodeInterface * BST:: getRootNode() const
    {
        return root; 
    }


	bool BST:: add(int data)
	{
	    add_function( root , data ); 
	    //cout << "add succccc" << endl; 
	}
	
	bool BST:: add_function(Node *& n, int value)
	{
	    if (n == NULL) // nothing entered yet 
	    {
	        n = new Node(value); 
	        return true; 
	    }
	    
	    if ( n->data > value )
	    {
	        return add_function( n->left, value); 
	    }
	   
	    if ( n->data < value )
	    {
	        return add_function( n->right, value); 
	    }
	    
	    return false; 
	}
	
    bool BST:: remove(int data)
    {
        remove_function( root, data );
    }
    
    bool BST:: remove_function(Node*& n, int value)
    {
        if (n == NULL) // not found 
	    {
	        return false;  
	    }
	    
	    if ( n->data > value )
	    {
	        return remove_function( n->left, value); 
	    }
	   
	    if ( n->data < value )
	    {
	        return remove_function( n->right, value); 
	    }
	    //if its not smaller or larger and we know its there it has to be equal to 
	    //removing logic---------------
	    
	    if ( n->right == NULL & n->left == NULL) //no children 
	    {
	        delete n;
	        n = NULL; 
	        return true; 
	    }
	    
	    if ( n->right == NULL || n->left == NULL) // one child 
	    {
	        Node * temp = n->left;
	        if (n->left == NULL)
	        {
	            temp = n->right;
	        }
	        delete n;
	        n = temp; 
	        return true; 
	    }
	    
	    //only case left is 2 children
	    
	    Node * temp = n->left;
	    Node * parent = n; 
	    while ( temp->right != NULL)
	    {
	        parent = temp; 
	        temp = temp->right; 
	    }
	    if (n->data != parent->data)
	    {
	    	parent->right = temp->left;
	    }
	    else
	    {
	    	parent->left = temp->left; 
	    }
	    n->data = temp->data;
	    delete temp; 
	    
	    
	    
	    return true; 
    }

	void BST:: clear()
	{
	    clear_function(root);
	    root = NULL; 
	}
	
	void BST:: clear_function( Node * n)
	{
	    if (n == NULL)
	    {
	        return; 
	    }
	    if (n->left != NULL)
	    {
	        clear_function(n->left); 
	    }
	    if (n->right != NULL)
	    {
	        clear_function(n->right);
	    }
	    
	    delete n; 
	    //n = NULL; 
	}