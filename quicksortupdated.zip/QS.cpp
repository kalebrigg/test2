#include "QS.h"

	QS :: ~QS()
	{
		clear(); 
	}
	
	
/////////////////FILE 1 FUNCTIONS///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	bool QS::createArray(int capacity)
    {
		
        if ( capacity <= 0 )
        {
            return false; //Returns false if the given capacity is non-positive
        }
	    array_size = capacity;// need for addToArray
	    
	    if ( ptr != NULL)
	    {
	    	cout << "ARRAY ALREADY EXISTING DELETE NOW              " << endl; 
	        int *place_holder_pointer; //Stack overflow
	        place_holder_pointer = ptr;
	        ptr = NULL; //if a previous array had been allocated, delete the previous array.
	        delete[] place_holder_pointer;
	        array_position = 0; 
	    }
	    
	    ptr = new int[capacity];// Stack overflow. Dynamically allocates an array with the given capacity. (array named array)
	       
	      return true; //true otherwise.

    }

    int QS:: getSize() const
    {
        return array_position; // dont return array size because that holds capacity not what we've actually put into the array 
    }
    
    bool QS:: addToArray(int value)
	{
		cout << "array position: " << array_position << endl; 
		cout << "array size -1 : " << (array_size - 1) << endl; 
		
		if (array_position > (array_size - 1))//If the array is filled, do nothing. array_size - 1 because array starts at 0 
		{
			return false; //false otherwise.
		}
		//ptr points to first element of array so need to be able to move its position up with the position of array 
		//as array position is incremented itll move to the next position and assign that dereferenced element that value
		
		*(ptr + array_position) = value; //STACK OVERFLOW. Adds the given value to the end of the array starting at index 0.
		cout << "test:    " << *(ptr + array_position) << endl; 
		array_position ++; 
		
		return true;  // returns true if a value was added, 
		
		
	}
    
    
	string QS:: getArray() const
	{
	/*
	* Produces a comma delimited string representation of the array. For example: if my array
	* looked like {5,7,2,9,0}, then the string to be returned would look like "5,7,2,9,0"
	* with no trailing comma.  The number of cells included equals the number of values added.
	* Do not include the entire array if the array has yet to be filled.
	*
	* 
	*
	* @return
	*		the string representation of the current array
	*/
	
		if ( ptr == NULL )//if the array is NULL or empty.
		{
			return ""; //Returns an empty string, if the array is NULL or empty.
		}
	/*
		string output_string = "";
		
	//	cout << "array position: " << array_position << endl; 
	//	cout << "test:    " << *(ptr + array_position) << endl;
		
		for (int i = 0; i < array_position ; i++ )//The number of cells included equals the number of values added.
		{
		
		//	string intStr = std::to_string(*(ptr + i));//casts int to string 
		//	output_string += (intStr);
		
		//	output_string +=  *(ptr + i);
		
			output_string +=  to_string(*(ptr + i));
			if ( i != array_position - 1 )
			{
				output_string += ",";
			}
			
			cout << "PTR:               " << *(ptr + i) << endl; 
			cout << "OUTPUT:            " << output_string<< endl;
		}
	*///DIDNT WORK 
		
	    stringstream output;
	    
	    for(int i = 0; i < array_position; i++)
	    {
	    	
	    	output << *(ptr+i);
	    	if( i != (array_position - 1))
	    		output << "," ;
	    		
	    			//cout << "PTR:               " << *(ptr + i) << endl; 
			    	//	cout << "OUTPUT:            " << output.str()<< endl;
	    }
	    return output.str();
	}
   
	void QS:: clear()
	{
	   
	    delete[] ptr; 
	    ptr = NULL;//Resets the array to an empty or NULL state.
    
        array_size = 0;
        array_position = 0; 
        
	}
	
/////////////////FILE 2 FUNCTIONS///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	 int QS:: medianOfThree(int left, int right)
    {
	    /*
		* medianOfThree()
		*
		* The median of three pivot selection has two parts:
		*
		* 1) Calculates the middle index by averaging the given left and right indices:
		*
		* middle = (left + right)/2
		*
		* 2) Then bubble-sorts the values at the left, middle, and right indices.
		*
		* After this method is called, data[left] <= data[middle] <= data[right].
		* The middle index will be returned.
		*
		* Returns -1 if the array is empty, if either of the given integers
		* is out of bounds, or if the left index is not less than the right
		* index.
		*
		* @param left
		* 		the left boundary for the subarray from which to find a pivot
		* @param right
		* 		the right boundary for the subarray from which to find a pivot
		* @return
		*		the index of the pivot (middle index); -1 if provided with invalid input
		*
		*/
		
		// remember they are indices NOT VALUES 
		
		if ( left >= right ||  left < 0 /*cant be a negative index*/ || array_position == 0 /*empty*/ || right >= array_position /*index cant be past last array index*/ ) 
		{
			return -1; 
		}
		
		int middle = (left + right)/2;  // from top 
		
		//BUBBLE SORT
		// bubble sort takes a pair of values
		// checks if the values in a pair are out of order
		// if yes, swap the two values 
		// keep doing until the array is sorted
		
		//we only have 3 values every single time so we only need to bubble sort 2 times 
		// after first pass [0]
		//                  [1]
		//					[2]    only [2] will be sorted, after second pass [1] will be sorted, and that makes [0] sorted as well
		// use dereferenced pointer plus left/mid/right to get to that index (*(ptr + _______))
		
		for ( int i = 0; i < 2 ; i++)
		{
			if ( *(ptr +left) > *(ptr + middle))
			{
			    int lefty = *(ptr + left);
				int middly = *(ptr + middle);
				int place_holder;																							//BOOK CODE
				place_holder = lefty;
				lefty = middly;
				middly = place_holder; 
				
				*(ptr +left)=lefty;
				*(ptr +middle)=middly;
			}
			//copy same thing but comparing new middle with right 
			if ( *(ptr + middle) > *(ptr + right))
			{
			    int middly = *(ptr + middle);
				int righty = *(ptr + right);
				int place_holder; 
				place_holder = middly;
				middly = righty;
				righty = place_holder; 
				
				*(ptr +right)=righty;
				*(ptr +middle)=middly;
			}
		}
	
		
		return middle; 
		
		
    }
/////////////////FILE 3 FUNCTIONS///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	int QS:: partition(int left, int right, int pivotIndex)
	{
		/*
	* Partitions a subarray around a pivot value selected according to
	* median-of-three pivot selection.  Because there are multiple ways to partition a list,
	* we will follow the algorithm on page 611 of the course text when testing this function.
	*
	* The values which are smaller than the pivot should be placed to the left
	* of the pivot; the values which are larger than the pivot should be placed
	* to the right of the pivot.
	*
	* Returns -1 if the array is null, if either of the given integers is out of
	* bounds, or if the first integer is not less than the second integer, or if the
	* pivot is not within the sub-array designated by left and right.
	*
	* @param left
	* 		the left boundary for the subarray to partition
	* @param right
	* 		the right boundary for the subarray to partition
	* @param pivotIndex
	* 		the index of the pivot in the subarray
	* @return
	*		the pivot's ending index after the partition completes; -1 if
	* 		provided with bad input
	*/
	
		//error check
		if ( array_position == 0 /*empty*/ || left < 0 /*out of bounds*/ || right >= array_position /*out of bounds*/ || left >= right /*right must always be bigger*/ || left > pivotIndex || right < pivotIndex ) 
			return -1; 
	
		//PARTITION ( BOOK HELPS WITH SOME OF THIS)
		//put the pivotindex into left, left goes pivot index              MUST SWITCH BACK AT THE END 
		//initialize: up = left +1 .... down = right                 BOOK: book has down = right - 1 because their last points to one after the last index 
		//Do
		//	 increment up until it finds element greater than pivot value or it finishes looking (while loop)
		//   decrement down until it finds element less than or equal to the pivot value or it finishes looking (while loop)
		//	 if up < down switch up and down               keeps doing this everytime is finishes the two while loops to get to that spot
		//While - up < down  ( to the left(smaller) than down) 
		//then switch back and return down 
		
		//same switches as bubble //dont use lefty righty just causes confusion 
		
		int place_holder = *(ptr+pivotIndex);
		*(ptr+pivotIndex) = *(ptr+left);
		*(ptr+left)=place_holder;
		
		int up = left + 1;
	//	int uppy = *(ptr + up);
		int down = right; 
	//	int downy = *(ptr + down);
		
		do
		{
			while ((up != down) && !((*(ptr + left)) < ( *(ptr+up)) ) )
			{
				++up; // book uses ++ first.. dont know the difference of ++ after 
			//	cout << "Stuck in loop 1" << endl; 
			}
                                                                                                       //book code here.cant use lefty,downyuppy ect. because they change from declaration
			while (*(ptr+left) < *(ptr+ down))
			{
				--down; 
			//	cout << "Stuck in loop 2" << endl; 

			}
			
			if ( up < down )
			{
				int place_holder2 = *(ptr + up);
				*(ptr + up) = *(ptr + down);
				*(ptr + down) = place_holder2; 
			}
			
			
			
		//	cout << "Stuck in big loop" << endl; 

		} while( up < down);
		
		// swap left,down 
		
		int place_holder3 = *(ptr+down);
		*(ptr+down) = *(ptr+left);
		*(ptr+left)= place_holder3;
		
	
		return down;
		
		
	}

/////////////////FILE 5 FUNCTIONS///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	void QS:: sortAll()
	{
	/*
		Sorts elements of the array.  After this function is called, every
	* element in the array is less than or equal its successor.
	*
	* Does nothing if the array is empty.
	*/
	
	//this will be the recursive helper function // need this because we have to pass in parameters 
		recursiveFunction( 0/*first index*/, (array_position  - 1) /*last index*/);
	
	}

	void QS:: recursiveFunction(int left, int right) //book uses first and last like in partition 
	{
		if ( (right - left) >= 1) 
		{
			int pivot = partition( left, right, /*pivotIndex.. to get just call median of three*/ medianOfThree(left, right));
			
		//tracers////////////////////
			cout << "PIVOT:       " << pivot << endl; 
			cout << "LEFT:        " << left << endl; 
			cout << "RIGHT:       " << right << endl << endl; 
			for ( int i = 0; i < array_position; i++)
			{
				cout << "ARRAY at " << i << ": " << *(ptr+i) << endl; 
			}
			cout << endl;
		/////////////////////////////	
		
			recursiveFunction(left, (pivot - 1));
			recursiveFunction( (pivot+1), right);
			
		}
		
	}
