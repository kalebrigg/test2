#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <fstream>
#include <streambuf>
#include <iomanip>
#include <map>
#include <set>
#include <sstream>
#include <list>
 
using namespace std;

string remove_punctuation(string word)
{
    string no_punc_string = "";
    for (unsigned int i = 0; i < word.size(); i++)
    {
        /*if (isupper(word[i]))
        {
                word[i] = tolower(word[i]);
        }*/
        /*
        if (isspace(word[i]))
        {
            return no_punc_string; 
        }
        
        if (word[i] == '-'')
        {
            word[i] = ' '
        }
        */
       
        if (isalpha(word[i]))
        {
            no_punc_string = no_punc_string + word[i];
        }
    }
    return no_punc_string;
    
}



void read_file(string file_name)
{
   
    set <string> input_file_set;
//////////////////////////////////////////////////////////////////////////create set
    ifstream input_file;
    string word; 
    
    string file_name_txt = file_name + ".txt";
    input_file.open(file_name_txt);
    
    string str((istreambuf_iterator<char>(input_file)), istreambuf_iterator<char>());
    //cout << str; 
    /*
    stringstream ss;
    ss << str; 
    
    //cout << ss.str(); 

    ss >> word; 
    //cout << "ss done" << endl;
    while (ss >> word)
    {
        for (unsigned int i = 0; i < word.size(); i++)
        {
            
            if ( word[i] == '-' && word[i + 1] == '-')
            {
                word[i] = ' '; 
            }
        }
    }
    */
    for (unsigned int i = 0; i < str.size(); i++)
    {
        if (str.at(i) == '-' && str.at(i+1) == '-')
        {
            str.at(i) = ' ';
            str.erase(i+1,1);
        }
        else if (str.at(i) == '-')
        {
            str.at(i) = ' ';
        }
    }
    stringstream ss;
    ss << str; 
    while (ss >> word)
    {
        //cout << word; 
       // word = remove_hyphen(word)
        word = remove_punctuation(word);
        input_file_set.insert(word);
    }
    
    input_file.close();
    
    
    
//////////////////////////////////////////////////////////////////////////output set
    set<string>::iterator iter;
    ofstream out_file;
    string output_file_name = file_name + "_set.txt";
    out_file.open(output_file_name);
     
    for (iter = input_file_set.begin(); iter != input_file_set.end(); iter++)
    {
        out_file << (*iter) << endl; 
    }
    out_file.close(); 
    
}

void read_vector_file(string file_name)
{
//////////////////////////////////////////////////////////////////////////create vector

    string word; 
    string no_punc_string = "";
    vector<string> input_file_vector;
    ifstream input_file;
    string file_name_txt = file_name + ".txt";
    input_file.open(file_name_txt);
    string str((istreambuf_iterator<char>(input_file)), istreambuf_iterator<char>());
    for (unsigned int i = 0; i < str.size(); i++)
    {
        if (str.at(i) == '-' && str.at(i+1) == '-')
        {
            str.at(i) = ' ';
            str.erase(i+1,1);
        }
        else if (str.at(i) == '-')
        {
            str.at(i) = ' ';
        }
    }
    stringstream ss;
    ss << str; 
    
     while( ss >> word )
     { 
         word = remove_punctuation(word);
         input_file_vector.push_back(word); 
     }
     input_file.close(); 
     

    
//////////////////////////////////////////////////////////////////////////output vector
    set<string>::iterator iter;
    ofstream out_file;
    string output_file_name = file_name + "_vector.txt";
    out_file.open(output_file_name);
     
    for (unsigned int i = 0; i < input_file_vector.size(); i++)
    {
        out_file << input_file_vector[i] << endl; 
    }
    out_file.close(); 
  
  //////////////////////////////////////////////////////////////////////////create map for string of vectors & output map 
  
  map<string, string> wordmap;
  string last ="";
  
  ofstream out_file_map;
  string output_file_map = file_name + "_1_1.txt";
  out_file.open(output_file_map);
  
  for(unsigned int i = 0; i < input_file_vector.size(); i++)
  {
      wordmap[last]=input_file_vector.at(i); 
      out_file << last << ", " << wordmap[last] << endl; 
      last = input_file_vector.at(i); 
      
  }
   out_file.close(); 
   
   string state = ""; 
    
    for (int i = 0; i < 100; i++)
    {
        cout << wordmap[state] << " ";
        state = wordmap[state];
    }
    cout << endl; 
//////////////////////////////////////////////////////////////////////////New map, Map:[string][vector]   & Output
  
  
  
  map<string, vector<string> > wordmap2;
  string statee ="";

  for(vector<string>::iterator it=input_file_vector.begin(); it!=input_file_vector.end(); it++)
  {
      wordmap2[state].push_back(*it);
      state = *it;
  }
  
  
  map<string, vector<string> >::iterator iterr = wordmap2.begin();
  
  iterr++;
  iterr++;
  iterr++;
  iterr++;
  iterr++;
  
  cout << endl << "Part 5, Begin Map print: " << endl; 
  cout << "Key: " << iterr->first << " ";
  cout << "Value: "; 
  

  for (int i = 0; i < iterr->second.size(); i++)
  {
      cout << iterr->second[i] << " "; 
  }
  cout << endl; 
/////////////////////////////////////////////////////////////////////////////////////////////  
  
  cout << endl << "One Word Context 100 Word Sermon: " << endl << endl; 
  
    srand(time(NULL));
    
    string stateee="";
    for (int i = 0; i < 100; i++)
    {
        while (wordmap2[stateee].size() == 0)
        {
            stateee= input_file_vector.at(rand() % input_file_vector.size());
        }
        int ind = rand() % wordmap2[stateee].size(); 
        
        cout << wordmap2[stateee][ind] << " ";
        stateee= wordmap[stateee][ind];
    }
    cout << endl << endl; 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////    
    
    
    
    map< vector<string>, vector<string> > wordmap3;
    vector <string> skate;
    int M = 3; 
    for (int i = 0; i < M; i++)
    {
        skate.push_back("");
    }
    
    for (vector<string>::iterator it = input_file_vector.begin(); it!= input_file_vector.end(); it++)
    {
        wordmap3[skate].push_back(*it);
        skate.push_back(*it);
        skate.erase (skate.begin()); 
    }
    
    /*
    list<string>state;
    for(int i = 0; i < M; i++)
    {
        state.push_back("");
    }
    */
    cout  << "Three Word Context 100 Word Sermon: " << endl << endl; 
    for (int i = 0; i < 100; i++)
    {
        
        if (wordmap3[skate].size() == 0)
        {
            skate.erase (skate.begin(),skate.end());
            for (int i = 0; i < M; i++)
            {
                skate.push_back("");
            }
        }
        
        
        int inds = rand() % wordmap3[skate].size();
        cout << wordmap3[skate][inds] << " ";
        skate.push_back(wordmap3[skate][inds]);
        skate.erase (skate.begin()); 
    }
    cout << endl; 
    
    
  
}


int main(int argc,  char* argv[])
{
    //set <string> input_file_set;
    
    read_file(argv[1]); 
    read_vector_file(argv[1]);
   
   
   
return 0;
}