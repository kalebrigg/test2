#include "Pathfinder.h"

	string Pathfinder:: toString() const
	{
	    stringstream ss; 
	    
	    for (int i = 0; i < 5; i++)
	    {
	        for (int j = 0; j < 5; j ++)
	        {
	            
	            for (int k = 0; k < 5; k ++)
	            {
	                if (k < 4)
	                    ss << maze[k][j][i] << " "; 
	                else 
	                    ss << maze[k][j][i]; 
	            }
	            ss << endl; 
	        }
	        if (i < 4)
	        {
	            ss << endl; // gives endl but not an extra at the end; 
	        }
	    }
	    return ss.str();
	}

	/*
	* createRandomMaze
	*
	* Generates a random maze and stores it as the current maze.
	*
	* The generated maze must contain a roughly equal number of 1s and 0s and must have a 1
	* in the entrance cell (0, 0, 0) and in the exit cell (4, 4, 4).  The generated maze may be
	* solvable or unsolvable, and this method should be able to produce both kinds of mazes.
	*/
	void Pathfinder:: createRandomMaze()
	{
		for (int i = 0; i < 5; i++)
	    {
	        for (int j = 0; j < 5; j ++)
	        {
	            for (int k = 0; k < 5; k ++)
	            {
	                maze[k][j][i] = rand() % 2;
	            }
	        }
	    }
	    maze[0][0][0] = 1;
	    maze[4][4][4] = 1;
	    }
	//-----------------------------------------------------------------------------------------

	//Part 2-----------------------------------------------------------------------------------
	/*
	* importMaze
	*
	* Reads in a maze from a file with the given file name and stores it as the current maze.
	* Does nothing if the file does not exist or if the file's data does not represent a valid
	* maze.
	*
	* The file's contents must be of the format described above to be considered valid.
	*
	* Parameter:	file_name
	*				The name of the file containing a maze
	* Returns:		bool
	*				True if the maze is imported correctly; false otherwise
	*/
	bool Pathfinder:: importMaze(string file_name)
	{
		ifstream input(file_name);
		int tempmaze[5][5][5];
		
		//stringstream ss; 
		//string line; 
		
		    for (int i = 0; i < 5; i++)
	        {
                for (int j = 0; j < 5; j ++)
                {
                    for (int k = 0; k < 5; k ++)
                    {
                        string value;
                        input >> value;
                        if (value != "1" && value != "0")
                        {
                            return false; 
                        }
                        tempmaze[k][j][i] = stoi(value); 
                    }
                }
            }
        while (!(input.eof()))
		{
		    string extra; 
		    input >> extra;
            if ( extra != " " && extra != "\n")
            {
                return false; 
            }
		}
		if (tempmaze[0][0][0] == 1 && tempmaze[4][4][4] == 1)
		{
		    for (int i = 0; i < 5; i++)
	        {
                for (int j = 0; j < 5; j ++)
                {
                    for (int k = 0; k < 5; k ++)
                    {
                        
                        maze[k][j][i] = tempmaze[k][j][i]; 
                    }
                }
            }  
		}
		else   
		    return false; 
		
		
		return true; 
	}

	vector<string> Pathfinder:: solveMaze()
	{
		P.clear();
		findPath(0,0,0);
		
		for (int k = 0; k < 5; k++)  //resets values of the maze from 2 back to 1
		{
			for (int j = 0; j < 5; j++)
			{
				for (int i = 0; i < 5; i++)
				{
					if (maze[i][j][k] == 2)
					{
						maze[i][j][k] = 1;
					}
				}
			}
		}

		return P;
	}
	
	bool Pathfinder::findPath(int x, int y, int z)
	{
		if (x < 0 || x > 4 || y < 0 || y > 4 || z < 0 || z > 4)
		{
	//		P.pop_back();
			return false;
		}
		if (maze[z][y][x]==0 || maze[z][y][x]==2 )
		{
	//		P.pop_back();
			return false;
		}
		if (x == 4 && y == 4 && z == 4 )
		{
			P.push_back("(4, 4, 4)");
			return true;
		}
		P.push_back("(" + to_string(z) + ", " + to_string(y) + ", " + to_string(x) + ")");

		maze[z][y][x] = 2;

		if (findPath(x - 1, y, z))
			return true;
		else if (findPath(x + 1, y, z))
			return true;
		else if (findPath(x, y - 1, z))
			return true;
		else if (findPath(x, y + 1, z))
			return true;
		else if (findPath(x, y, z - 1))
			return true;
		else if (findPath(x, y, z + 1))
			return true;
		else
		{
			P.pop_back();
			return false;
		}
		return false;
	}