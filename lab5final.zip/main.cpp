/*#include <iostream>
#include <string>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <stdio.h>
#include <ctype.h>*/
#include "Linked_List.h"

using namespace std;

int main(int argc,  char* argv[])
{
    
    string word;
    string line; 
    string name; 
    int index; 
    
   // cout << "start program" << endl; 
    Linked_List<string> L; 
    
//////////////// Reading in input
    ifstream input_file; 
    input_file.open(argv[1]);
    
    ofstream out_file;
    out_file.open(argv[2]);
    
    
    while(getline(input_file, line))
    {
        //cout << "start stringstream" << endl;
        stringstream ss(line);
        while ( ss >> word)
        {
            //cout << endl << "ss word: " << word << endl << endl; 
                    ////////////CLEAR
            if ( word == "clear")
            {
              //  cout << "start clear" << endl;
                L.clear();
                out_file << "clear" << endl;
              //  cout << "clear finished" << endl; 
                
            }   
            
                   /////////////INSERT
            else if ( word == "insert" )
            {
                /*
                while ( ss >> index >> name)
                {
                    L.insert(index, name);
                    out_file << "insert " << index << " " << name << endl;
                }
                */
                ss >> index >> name; 
                L.insert(index, name);
                out_file << "insert " << index << " " << name << endl;
                
            }
            
                  /////////////PRINT
            else if ( word == "print" )
            {
                out_file << "print" << endl;
                string print = L.print();
                out_file << print; 
            }
            
                 /////////////FIND
            else if ( word == "find" )
            {
                /*
                while ( ss >> name )
                {
                    L.find( name );
                    int number = L.find(name); 
                    out_file << "find " << name << " " << number << endl;
                }*/
                
                ss >> name; 
                L.find( name );
                int number = L.find(name); 
                out_file << "find " << name << " " << number << endl;
            }
            
                //////////////REMOVE
            else
            {
                ss >> index;
               // L.remove_item(index); 
                
                string remove_string = L.remove_item(index);
                out_file << remove_string;
                    
                    
                    //string remove_print = L.remove_item(index); 
                   // out_file << remove_print;
/*
                    string index_name = L.remove_item(index); 
                    if (index_name == "not found")
                    {
                        out_file << "remove " << index  << endl;  
                    } 
                    else 
                    {
                        out_file << "remove " << index << " " << index_name << endl; 
                    }    
                    
                    */
            }
            
        }
    }
    input_file.close();
    out_file.close(); 
    return 0;
}