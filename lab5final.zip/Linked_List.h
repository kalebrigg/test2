#include <iostream>
#include <string>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <stdio.h>
#include <ctype.h>
#include <sstream>

using namespace std;

template <typename T>
class Linked_List
{
    private:
    
        struct Node
        {
            public:
            
            T item; 
            Node* next;
            Node* prev; 
            Node* index;        /////////////////added 
        };
        
        Node* n;
        Node* head; 
        Node* tail; 
        Node* temp; 
        Node* curr;
        
        
        int size; 
        //int index;         ////////////////added
    
    public:
        //template <typename T>
        Linked_List()
        {
            
            head = NULL;
            temp = NULL;        //// MAKE THIS ONLY IN A FUCTION ///////////
            tail = NULL; 
            curr = NULL; 
            size = 0; 
            
        }
        
       ~Linked_List()      //deconstructor
       {
           clear();
           
           /*
           curr = head;
            
            while(curr->next != NULL)
            {
                temp = curr->next;  
                delete curr;
                curr = temp; 
            }
            
            delete curr; */
       }
         
        
        void clear()
        {
            if( head == NULL || tail == NULL )
            {
                //cout << "clear" << endl;
                return;
            }
            else
            {
                curr = head;
            
                while(curr->next != NULL)
                {
                    temp = curr->next;  
                    delete curr;
                    curr = temp; 
                }
                
                delete curr; 
              //  cout << "clear" << endl; 
            }
            size = 0; 
            head = NULL;
            tail = NULL; 
        }
        
        void insert(int index, const T& item)
        {
            
            Node* n = new Node; 
            
            n->next = NULL; 
            n->prev = NULL;
            n->item = item;
            
            //cout << "insert " << index << " " << n->item << endl; 
            
            if ( head == NULL )
            {
                head = n;
                tail = n; 
                size +=1;
                return; 
            }
            if ( size == 1)
            {
                if (index == 0)
                {
                    curr = head;
                    head = n; 
                    n->next = curr;
                    curr->prev = n; 
                    size +=1;
                    return;
                }
                
                curr = tail;
                tail = n; 
                n->prev = curr;
                curr->next = n; 
                size +=1;
                return;
            }
            if (index < size/2)
            {
                head_func(n, index);
            }
            else 
            {
                tail_func(n, index);
            }
        
        }
        
        string print()
        {
            stringstream ss; 
            string string; 
            //cout << "print" << endl;
            //ss << "print" << endl; 
            curr = head;
            
            for ( int i = 0; i <= size - 1; i++)
            {
             //   cout << "node " << i << ": " << curr->item << endl; 
                ss << "node ";
                ss << i; 
                ss << ": ";
                ss << curr->item; 
                ss << endl;
                if ( curr->next == NULL )
                {
                    return ss.str(); 
                }
                
                curr = curr->next; 
             
            }
            return string;
             
        }
        
        int find (const T& item)
        {
            //Node* find_pointer = NULL;
            curr = head; 
           
            for ( int i = 0; i <= size - 1; i++)
            {
                if (curr->item == item)
                {
                   // cout << "find " << curr->item << " " << i << endl; 
                    return i; 
                }
                curr = curr->next; 
            }
         
            //cout << "find " << item << " -1" << endl; 
            return -1; 
        }
        
        string remove_item(int index)        
        {
         
            stringstream tt;
            if (index >= size)
            {
              //  cout << "remove " << index << endl; 
                tt << "remove " << index << endl;
                return tt.str();
            }
                 
            if (size == 1)
            {
                Node* delete_pointer = NULL;
                delete_pointer = head; 
              //  cout << "remove " << index << " " << delete_pointer->item << endl;
                tt << "remove " << index << " " << delete_pointer->item << endl;
                head = NULL;
                tail = NULL;
                delete delete_pointer;
                size--; 
                return tt.str();
            }
            if (index < size/2)
            {
                Node* delete_pointer = NULL;
                temp = head;
                curr = head;
                int position = 0;
                
                for (int i = 0; i < index; i++)
                {
                    position++;
                    temp = curr;
                    curr = curr->next;
                }
                if ( position == 0 )
                {
                    delete_pointer = temp; 
                    curr = curr->next;
                    head = curr;
                    curr->prev = NULL;
                    temp = temp->next;
                 //   cout << "remove " << index << " " << delete_pointer->item << endl;
                    tt << "remove " << index << " " << delete_pointer->item << endl; 
                    delete delete_pointer;
                    
                    size--; 
                    
                    return tt.str();
                } 
                
                delete_pointer = curr; 
                curr = curr->next;
                temp->next = curr; 
                curr->prev = temp;
              //  cout << "remove " << index << " " << delete_pointer->item << endl; 
                 tt << "remove " << index << " " << delete_pointer->item << endl; 
                delete delete_pointer;
               
                size--; 
            
                
                return tt.str(); 
            }
            
            else 
            {
                Node* delete_pointer = NULL;
                temp = tail;
                curr = tail; 
                int position = size - 1;
                
                for (int i = size - 1; i > index; i--)
                {
                    position--;
                    temp = curr;
                    curr = curr->prev;
                }
                if ( position == size - 1)
                {
                    delete_pointer = temp; 
                    curr = curr->prev;
                    tail = curr;
                    curr->next = NULL;
                    temp = temp->prev;  
                 //   cout << "remove " << index << " " << delete_pointer->item << endl; 
                    tt << "remove " << index << " " << delete_pointer->item << endl;
                    delete delete_pointer;
                    
                    size--; 
                    
                    return tt.str();
                } 
                
                delete_pointer = curr; 
                curr = curr->prev;
                temp->prev = curr; 
                curr->next = temp;
              //  cout << "remove " << index << " " << delete_pointer->item << endl; 
                 tt << "remove " << index << " " << delete_pointer->item << endl; 
                delete delete_pointer;
               
                size--; 
                
                return tt.str();
            }
                
                
        }
        void head_func(Node* n, int index)
        {
            curr = head; 
                
            for( int i = 0; i < index; i++)
            {
                curr = curr->next; 
            }
        
            if (index == 0)
            {
                head = n;
                n->next = curr;
                curr->prev = n; 
                size += 1; 
            }
            
            else
            {
                n->prev = curr->prev;
                n->next = curr;
                if( curr->prev != NULL)
                {
                    curr->prev->next = n; 
                }
                curr->prev = n; 
                //n->prev->next = n; 
                size += 1; 
            }
                
        }
        void tail_func(Node* n, int  index)
        {
            curr = tail;
                
            for( int i = size - 1 ; i > index; i--)
            {
                curr = curr->prev; /////////////////////////
            }
        
            if (index == size)
            {
                tail = n;
                n->prev = curr;
                curr->next = n;
                    // temp = n->prev; 
                    // curr->prev = n; 
                    // n->next = curr;
                    // n = temp->next;  
                size += 1; 
            }
            
            else
            {
                n->prev = curr->prev;
                n->next = curr;
                if ( curr->prev != NULL )
                {
                    curr->prev->next = n; 
                }
                curr->prev = n; 
                //n->prev->next = n; 
                size += 1; 
            }
        }
};
