//
//  School.cpp
//  Lab1 - Grades
//
//  Created by Kaleb Rigg on 6/29/17.
//  Copyright © 2017 Kaleb Rigg. All rights reserved.
//

#include "School.h"
using namespace std;

School::School()
{

}

void School:: read_student_info(string file_name)
{ 
    ifstream student_input;
    string student_id;
    string student_name;
    string student_address;
    string student_phone;
    
    student_input.open(file_name);
    while(getline(student_input, student_id))
    {
        getline(student_input, student_name);
        getline(student_input, student_address);
        getline(student_input, student_phone);
        
        student_list.push_back(Student(student_id, student_name, student_address, student_phone));
    }
    student_input.close();
} 

void School:: output_student_file(string file_name)
{ 
    ofstream out_file;
    out_file.open(file_name, std::ios_base::app);
    
    for (unsigned int i = 0; i < student_list.size(); i++)
    {
        out_file << student_list[i].get_name() << endl;
        out_file << student_list[i].get_ID() << endl;
        out_file << student_list[i].get_phone() << endl;
        out_file << student_list[i].get_address() << endl;
        
    }
    out_file <<endl;
    
    //out_file.close();
}

void School:: read_course_info ( string file_name)
{
    ifstream student_grades;
    string student_grade_course;
    string student_grade_id;
    string student_grade_grade;
    
    student_grades.open(file_name);                  
    while(getline(student_grades, student_grade_course))
    {
        getline(student_grades, student_grade_id);
        getline(student_grades, student_grade_grade);
        
        student_list_grades.push_back(Grade(student_grade_course, student_grade_id, student_grade_grade));
    }
    student_grades.close(); 
}

void School:: output_grade_file(string file_name)
{
    ofstream out_file;
    out_file.open(file_name, std::ios_base::app);
     
     for(unsigned int i = 0; i < student_list_grades.size(); i++)
    {
        out_file << student_list_grades[i].get_grade_ID() << "\t";
        out_file << student_list_grades[i].get_grade_grade() << "\t";
        out_file << student_list_grades[i].get_grade_course() << endl;
        
    }
        out_file << endl; 
     //out_file.close();
}

void School:: read_query_file (string file_name)
{
    ifstream query_list;
    string student_query_id;
    query_list.open(file_name);
    while(getline(query_list, student_query_id))
    {
        student_query_list.push_back(student_query_id);
    }
    query_list.close();
}

void School:: output_query_file(string file_name)
{
    ofstream out_file;
    out_file.open(file_name, std::ios_base::app);
  
  for (unsigned int i = 0; i < student_query_list.size(); i++)  
  {
    for (unsigned int j = 0; j < student_list.size(); j++)
    {
        if (student_query_list[i] == student_list[j].get_ID())
        {
            out_file << student_list[j].get_ID();
            out_file << "\t";
            
            out_file << fixed << setprecision(2) << setfill('0') << get_gpa(student_query_list[i]);
            
            out_file << "\t" <<student_list[j].get_name();
            out_file << endl;
            
            break; 
        }
        
    }
  }
    //out_file.close();
}  

void School:: sort_student_list()
{
    sort(student_list.begin(), student_list.end());
}

void School:: sort_student_list_grades()
{
    sort(student_list_grades.begin(), student_list_grades.end());
}

double School:: get_gpa (string id)
{
    map <string, double> gradepoint;
    gradepoint["A"] = 4.0;
    gradepoint["A-"] = 3.7;
    gradepoint["B+"] = 3.4;
    gradepoint["B"] = 3.0;
    gradepoint["B-"] = 2.7;
    gradepoint["C+"] = 2.4;
    gradepoint["C"] = 2.0;
    gradepoint["C-"] = 1.7; 
    gradepoint["D+"] = 1.4;
    gradepoint["D"] = 1.0;
    gradepoint["D-"] = 0.7;
    gradepoint["E"] = 0.0;
    
    double points = 0;
    double gpa = 0;
    int number_of_grades = 0;
    double r = 0.0;
    
    for (unsigned int i = 0; i < student_list_grades.size(); i++)
    {
        if (student_list_grades[i].get_grade_ID() == id)
        {
                number_of_grades++;
                points = gradepoint[student_list_grades[i].get_grade_grade()];
                gpa +=points;
        }
    }
    if (gpa <= 0)
    {
        int w = 0.0;
        gpa = w; 
    }
    if (gpa == r )
    {
        return gpa;
    }
    else
    {
        gpa = gpa/number_of_grades;
        return gpa; 
    }
}