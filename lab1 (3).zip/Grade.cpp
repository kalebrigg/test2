//
//  Grade.cpp
//  Lab1 - Grades
//
//  Created by Kaleb Rigg on 6/29/17.
//  Copyright © 2017 Kaleb Rigg. All rights reserved.
//

#include "Grade.h"

using namespace std;

Grade::Grade()
{
    course = "";
    ID = "";
    grade = "";
}

Grade::Grade(string student_grade_course, string student_grade_id, string student_grade_grade)
{
    course = student_grade_course;
    ID = student_grade_id;
    grade = student_grade_grade;
}

bool Grade::operator < (Grade g) const 
{
    return ID < g.ID ||
      (ID == g.ID && course < g.course) ||
      (ID == g.ID && course == g.course && grade < g.grade);
}

string Grade:: get_grade_course()
{
    return course;
}

string Grade:: get_grade_ID()
{
    return ID;
}

string Grade:: get_grade_grade()
{
    return grade;
}