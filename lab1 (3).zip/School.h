//
//  School.h
//  Lab1 - Grades
//
//  Created by Kaleb Rigg on 6/29/17.
//  Copyright © 2017 Kaleb Rigg. All rights reserved.
//

#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <map>
#include "Student.h"
#include "Grade.h"

using namespace std;

class School
{
    private:
        vector<Student> student_list;
        vector<Grade> student_list_grades;    
        vector<string> student_query_list;
   
    public:
        School();
        
        
        void read_student_info(string file_name);
        void output_student_file(string file_name);
        void read_course_info ( string file_name);
        void output_grade_file(string file_name);
        void read_query_file (string file_name);
        void output_query_file(string file_name);

        void sort_student_list();
        void sort_student_list_grades();
        
        double get_gpa( string id);

};
