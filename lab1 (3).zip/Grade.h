//
//  Grade.h
//  Lab1 - Grades
//
//  Created by Kaleb Rigg on 6/29/17.
//  Copyright © 2017 Kaleb Rigg. All rights reserved.
//

#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class Grade
{
    
    private:
        string course;
        string ID;
        string grade;
    
    public:
        Grade();
        Grade(string student_grade_course, string student_grade_id, string student_grade_grade);
        
        bool operator < (Grade g) const; 

        string get_grade_course();
        string get_grade_ID();
        string get_grade_grade();
};      
