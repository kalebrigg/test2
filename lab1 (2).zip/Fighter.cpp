#include "Fighter.h"
#include <string>

    Fighter::Fighter(string fighter_name, int fighter_hitpoints, int fighter_strength, int fighter_speed, int fighter_magic) 
    {
        name = fighter_name;
        hit_points = fighter_hitpoints;
        current_hitpoints = hit_points;
        strength = fighter_strength;
        speed = fighter_speed;
        magic = fighter_magic; 
    }

	string Fighter::getName() const
	{
	    return name;
	}

	int Fighter::getMaximumHP() const
	{
	    return hit_points; 
	}
	
	int Fighter:: getCurrentHP() const
	{
	    return current_hitpoints; 
	}
	
	int Fighter:: getStrength() const
	{
	    return strength; 
	}

	int Fighter:: getSpeed() const
	{
	    return speed;
	}

	int Fighter:: getMagic() const
    {
        return magic;
    }
    /*
	int Fighter:: getDamage() 
    {
       
    }
    */
	void Fighter:: takeDamage(int damage)
    {
    	/*
    	Reduces the fighter's current hit points by an amount equal to the given
	*	damage minus one fourth of the fighter's speed.  This method must reduce
	*	the fighter's current hit points by at least one.  It is acceptable for
	*	this method to give the fighter negative current hit points.
		*/
        int damage_received = damage - (speed/4);//an amount equal to the given	damage minus one fourth of the fighter's speed
    	if (damage_received < 1)
    	{
    		damage_received = 1;//his method must reduce the fighter's current hit points by at least one.
    	}
    	current_hitpoints = current_hitpoints - damage_received;
    	
    }
    
    /*
	void Fighter:: reset()
    {
        
    }
    */
    
	void Fighter:: regenerate() //Cleric has special regen. 
    {
    	/*
    	Increases the fighter's current hit points by an amount equal to one sixth of
	*	the fighter's strength.  This method must increase the fighter's current hit
	*	points by at least one.  Do not allow the current hit points to exceed the
	*	maximum hit points.
    	*/
    	
    	 int regenerate_hitpoints = (strength/6); //Increases the fighter's current hit points by an amount equal to one sixth of the fighter's strength.
        
        if (regenerate_hitpoints < 1)
        {
            regenerate_hitpoints = 1;  //This method must increase fighter's current hitpoints by at least one.
        }
        if ( (hit_points-regenerate_hitpoints) > current_hitpoints )
        {
            current_hitpoints = current_hitpoints + regenerate_hitpoints;
        }
        else
        {
            current_hitpoints = hit_points; //Do not allow the current hit points to exceed the maximum hit points.
        }
        
    }
    /*
	bool Fighter:: useAbility()
	{
	     
	}
	*/