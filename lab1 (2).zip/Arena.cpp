#include "Arena.h"
#include <string>
/*
Arena::Arena()
{
    
}
*/
bool Arena:: addFighter(string info)
{
    /*
    Fighters are represented as strings when added to the arena. The following format is expected:
        (name) (type) (maximum hit points) (strength) (speed) (magic)
        Example: Xephos A 200 13 21 10
    The name is a single word; the type is a single capital letter ((R)obot, (A)rcher, or (C)leric); the remaining four stats are positive integers.
    */
    
    string name = " ";
    string type = " ";
    int hit_points = 0;
    int strength = 0;
    int speed = 0;
    int magic = 0; 
    string extra_string = " ";
   // int extra_int = 0; 
    
    stringstream ss(info); 
    if (ss >> name >> type >> hit_points >> strength >> speed >> magic)
    {
        
        if (ss >> extra_string)
        {
            return false; 
        }

        
        for ( unsigned int i = 0; i < fighters.size(); i++ ) //checks if duplicate fighter
        {
            if (name == fighters.at(i)->getName()) 
            {
                return false;
            }
        }
        
        
        //Distinguishing between Fighters
        
        if (type == "A")//Archer
        {
            fighters.push_back(new Archer(name, hit_points, strength, speed, magic));
        }
        
        else if (type == "C")//Cleric
        {
            fighters.push_back(new Cleric(name, hit_points, strength, speed, magic));
        }
        
        else if (type == "R")//Robot
        {
            fighters.push_back(new Robot(name, hit_points, strength, speed, magic));
        }
        
        else //not a archer, cleric, or robot
        {
            return false; 
        }
        
        return true; 
    }
    else
    {
        return false;
    }
    
}

bool Arena::removeFighter(string name)
{
    for ( unsigned int i = 0; i < fighters.size(); i++) 
    {
        if (name == fighters.at(i)->getName()) //goes through vector of
        {                                     //fighters to match name
            delete fighters.at(i); 
            fighters.erase(fighters.begin() + i);
            return true; 
        }
    }
    
    return false; 
}	

FighterInterface* Arena:: getFighter(string name)
{
	   for (Fighter* i : fighters)
	   {
	       if ( name == i->getName())
	       {
	           return i; 
	       }
	   }
	   return NULL;
}

int Arena:: getSize() const
{
    return fighters.size(); 
}