#include "Cleric.h"
#define CLERIC_ABILITY_COST 25

    Cleric:: Cleric (string fighter_name, int fighter_hitpoints, int fighter_strength, int fighter_speed, int fighter_magic) 
        :Fighter(fighter_name, fighter_hitpoints, fighter_strength, fighter_speed, fighter_magic)
    {
        maximum_mana = magic * 5;
        current_mana = maximum_mana;
    }
    
    int Cleric:: getDamage()
    {
        return magic; 
    }
    
    void Cleric:: reset()
    {
        current_hitpoints = hit_points; // same as other types of fighters
        current_mana = maximum_mana;
    }
    
    void Cleric:: regenerate()
    {
        /*
        Increases the fighter's current hit points by an amount equal to one sixth of
	*	the fighter's strength.  This method must increase the fighter's current hit
	*	points by at least one.  Do not allow the current hit points to exceed the
	*	maximum hit points.
	*
	*	Cleric:
	*	Also increases a Cleric's current mana by an amount equal to one fifth of the
	*	Cleric's magic.  This method must increase the Cleric's current mana by at
	*	least one.  Do not allow the current mana to exceed the maximum mana (again, 5 times its magic).
        */
        
        //hit points & mana.. similar implementation for both 
        
/////////////hitpoints first:
        
        int regenerate_hitpoints = (strength/6); //Increases the fighter's current hit points by an amount equal to one sixth of the fighter's strength.
        
        if (regenerate_hitpoints < 1)
        {
            regenerate_hitpoints = 1;  //This method must increase fighter's current hitpoints by at least one.
        }
        if ( (hit_points-regenerate_hitpoints) > current_hitpoints )
        {
            current_hitpoints = current_hitpoints + regenerate_hitpoints;
        }
        else
        {
            current_hitpoints = hit_points; //Do not allow the current hit points to exceed the maximum hit points.
        }
        
////////////Mana regen:
        
        int regenerate_mana = (magic/5); //increases a Cleric's current mana by an amount equal to one fifth of the Cleric's magic.
        
        if (regenerate_mana < 1)
        {
            regenerate_mana = 1; //This method must increase the Cleric's current mana by at least one.
        }
        if ( (maximum_mana - regenerate_mana) > current_mana )
        {
            current_mana = current_mana + regenerate_mana;
        }
        else
        {
            current_mana = maximum_mana;
        }
        
    }
    
	bool Cleric:: useAbility()
	{
    	/*
        *	Attempts to perform a special ability based on the type of fighter.  The
    	*	fighter will attempt to use this special ability just prior to attacking
    	*	every turn.
    	*
    	*	Cleric: Healing Light
    	*	Increases the Cleric's current hit points by an amount equal to one third of its magic.
    	*	Can only be used if the Cleric has at least [CLERIC_ABILITY_COST] mana.
    	*	Will be used even if the Cleric's current HP is equal to their maximum HP.
    	*	Decreases the Cleric's current mana by [CLERIC_ABILITY_COST] when used.
    	*	Cleric Note:
    	*	This ability, when successful, Decreases the Cleric's current mana by [CLERIC_ABILITY_COST] when used., unless doing so would given the Cleric more hit points than its maximum hit points.
    	*	Do not allow the current hit points to exceed the maximum hit points.
    	*  
    	*	Return true if the ability was used; false otherwise.
    	*/
    	
    	int ability_hitpoints = magic/3; //Increases the Cleric's current hit points by an amount equal to one third of its magic.
    	
    	if (current_mana < CLERIC_ABILITY_COST)//Can only be used if the Cleric has at least [CLERIC_ABILITY_COST] mana.
    	{
    	    return false; 
    	}
    	else
    	{
    	    current_mana = current_mana - CLERIC_ABILITY_COST;//Decreases the Cleric's current mana by [CLERIC_ABILITY_COST] when used.
    	    
    	    if (ability_hitpoints < 1)
    	    {
    	        ability_hitpoints = 1;//Decreases the Cleric's current mana by [CLERIC_ABILITY_COST] when used.
    	    }
    	    if( (hit_points-ability_hitpoints) > current_hitpoints )
    	    {
    	        current_hitpoints = current_hitpoints + ability_hitpoints;
    	    }
    	    else
    	    {
    	        current_hitpoints = hit_points;//Do not allow the current hit points to exceed the maximum hit points.
    	    }
    	    
    	    return true; 
    	    
    	}
	}