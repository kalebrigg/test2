#include "Robot.h"
#include <string>
#include <cmath>

    Robot:: Robot (string fighter_name, int fighter_hitpoints, int fighter_strength, int fighter_speed, int fighter_magic)
        :Fighter(fighter_name, fighter_hitpoints, fighter_strength, fighter_speed, fighter_magic)
        {
            maximum_energy = fighter_magic * 2;
            current_energy = maximum_energy; 
        }
        
    int Robot:: getDamage()
    {
        int damage = (strength + bonus_damage);
        bonus_damage = 0; // has to go back to zero everytime so that next time you use ability it changes
        return damage; 
    }
    
    void Robot:: reset()
    {
        current_hitpoints = hit_points;
        current_energy = maximum_energy;
        bonus_damage = 0; 
    }
    
    bool Robot:: useAbility()
    {   /*
        Robot: Shockwave Punch
	*	Adds bonus damage to the Robot's next attack (and only its next attack) equal to (strength  * ((current_energy/maximum_energy)^4)).
	*	Can only be used if the Robot has at least [ROBOT_ABILITY_COST] energy.
	*	Decreases the Robot's current energy by [ROBOT_ABILITY_COST] (after calculating the additional damage) when used.
	*		Examples:
	*		strength=20, current_energy=20, maximum_energy=20		=> bonus_damage=20
	*		strength=20, current_energy=15, maximum_energy=20		=> bonus_damage=6
	*		strength=20, current_energy=10, maximum_energy=20		=> bonus_damage=1
	*		strength=20, current_energy=5,  maximum_energy=20		=> bonus_damage=0
	*	Robot Note:
	*	The bonus damage formula should be computed using double arithmetic, and only
	*	the final result should be cast into an integer.
	    */
	
	    double ability_damage = 0.0;
	    if(current_energy < ROBOT_ABILITY_COST)
	    {
	        return false; //Can only be used if the Robot has at least [ROBOT_ABILITY_COST] energy.
	    }
	    
	    else
	    {
	        ability_damage = (strength * pow(  (static_cast<double>(current_energy) / static_cast<double>(maximum_energy)),4));
	        //cast current_energy and maximum_energy into doubles 
	        current_energy = current_energy - ROBOT_ABILITY_COST;
	        bonus_damage = static_cast<int>(ability_damage);
	        return true; 
	        
	    }
    }
    
    