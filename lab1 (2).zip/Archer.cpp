#include "Archer.h"

    Archer:: Archer(string fighter_name, int fighter_hitpoints, int fighter_strength, int fighter_speed, int fighter_magic)
        :Fighter (fighter_name, fighter_hitpoints, fighter_strength, fighter_speed, fighter_magic)
    {
        fighter_previous_speed = fighter_speed;
    }
    
    int Archer:: getDamage()
    {
        return speed;
    }
    
    void Archer:: reset()
    {
        current_hitpoints = hit_points;  //resets back to full health
        speed = fighter_previous_speed;
    }
    
    bool Archer:: useAbility()
    {
        speed++; 
        return true; 
    }