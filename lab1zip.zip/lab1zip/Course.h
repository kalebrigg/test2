//
//  Course.h
//  Lab1 - Grades
//
//  Created by Kaleb Rigg on 6/29/17.
//  Copyright © 2017 Kaleb Rigg. All rights reserved.
//

#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class Course
{
    private:
    
    public:
        Course();
        //load_vector();
    
};
