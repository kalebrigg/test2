//
//  Course.cpp
//  Lab1 - Grades
//
//  Created by Kaleb Rigg on 6/29/17.
//  Copyright © 2017 Kaleb Rigg. All rights reserved.
//

#include "Course.h"
using namespace std;

Course::Course()
{

}
