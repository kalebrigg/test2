//
//  Student.cpp
//  Lab1 - Grades
//
//  Created by Kaleb Rigg on 6/29/17.
//  Copyright © 2017 Kaleb Rigg. All rights reserved.
//

#include "Student.h"

using namespace std;

Student::Student()
{
    ID = "";
    name = "";
    address = "";
    phone = "";
    gradepoint = 0;
    return;
}

Student::Student(string student_id, string student_name, string student_address, string student_phone)
{
    ID = student_id;
    name = student_name;
    address = student_address;
    phone = student_phone;
    return;
}

bool Student::operator< (Student s) const
{
    return ID < s.ID;
}

string Student:: get_ID()
{
    return ID;
}
string Student:: get_address()
{
    return address;
}
string Student:: get_name()
{
    return name;
}
string Student:: get_phone()
{
    return phone;
}
void Student:: add_course_gpa(int)
{
    
    gradepoint += gradepoint;
    courses_taken++;
    
}






void Student::set_ID(string student_id)
{
    ID = student_id;
}
void::Student::set_address(string student_address)
{
    address = student_address;
}
void Student::set_name(string student_name)
{
    name = student_name;
}



string Student::toString()
{
    stringstream ss;
    ss << ID << endl;
    ss << name << endl;
    ss << address << endl;
    ss << phone << endl;
    return ss.str();
}
