//
//  Student.h
//  Lab1 - Grades
//
//  Created by Kaleb Rigg on 6/29/17.
//  Copyright © 2017 Kaleb Rigg. All rights reserved.
//

#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>

using namespace std;

class Student
{
    private:
        string ID;
        string address;
        string name;
        string phone;
        int gradepoint;
        int courses_taken;

    public:
    
        Student(); //default constructor
        Student(string student_id, string student_name,string student_address,  string student_phone); //secondary constructor
    
        bool operator < (Student s) const;    //operator overload
    
        string get_ID();
        void set_ID(string student_id);
        string get_address();
        void set_address(string student_address);
        string get_name();
        void set_name(string student_name);
        string get_phone();
        void set_phone();
    
        void add_course_gpa(int);
    
        string toString();
};


