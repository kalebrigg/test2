//
//  main.cpp
//  Lab1 - Grades
//
//  Created by Kaleb Rigg on 6/29/17.
//  Copyright © 2017 Kaleb Rigg. All rights reserved.
//

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <map>
#include "Student.h"
#include "Course.h"
#include "Grade.h"
 
//std::ios_base::app//
using namespace std;

/*void print (string file_name, vector<Student>& student_list, vector<Grade>& student_list_grades, vector<string>& student_query_list)
{
    ofstream out_file;
    out_file.open(file_name);
    
    for (unsigned int i = 0; i < student_list.size(); i++)
    {
        out_file << student_list[i].get_name() << endl;
        out_file << student_list[i].get_ID() << endl;
        out_file << student_list[i].get_phone() << endl;
        out_file << student_list[i].get_address() << endl;
        
    }
    out_file <<endl;
    
    for(unsigned int i = 0; i < student_list_grades.size(); i++)
    {
        out_file << student_list_grades[i].get_grade_ID() << "\t";
        out_file << student_list_grades[i].get_grade_grade() << "\t";
        out_file << student_list_grades[i].get_grade_course() << endl;
        
        ///call add grade to student function... school class 
         
    }
    
    float gpa = 0; 
  
  for (unsigned int i = 0; i < student_query_list.size(); i++)  
  {
    for (unsigned int j = 0; j < student_query_list.size(); j++)
    {
        if (student_query_list[i] == student_list[j].get_ID())
        {
            out_file << student_list[j].get_ID();
            out_file << "\t" << fixed << setprecision(2) << setfill('0') << gpa;
        }
    }
  }
}*/

void read_student_info( string file_name, vector<Student>& student_list)
{ 
    ifstream student_input;
    string student_id;
    string student_name;
    string student_address;
    string student_phone;
    
    student_input.open(file_name);
    while(getline(student_input, student_id))
    {
        getline(student_input, student_name);
        getline(student_input, student_address);
        getline(student_input, student_phone);
        
        student_list.push_back(Student(student_id, student_name, student_address, student_phone));
    }
    student_input.close();
}

void output_student_file(string file_name, vector<Student>& student_list)
{ 
    ofstream out_file;
    out_file.open(file_name, std::ios_base::app);
    
    for (unsigned int i = 0; i < student_list.size(); i++)
    {
        out_file << student_list[i].get_name() << endl;
        out_file << student_list[i].get_ID() << endl;
        out_file << student_list[i].get_phone() << endl;
        out_file << student_list[i].get_address() << endl;
        
    }
    out_file <<endl;
    
    //out_file.close();
}

void read_course_info ( string file_name, vector<Grade>& student_list_grades )
{
    ifstream student_grades;
    string student_grade_course;
    string student_grade_id;
    string student_grade_grade;
    
    student_grades.open(file_name);                  
    while(getline(student_grades, student_grade_course))
    {
        getline(student_grades, student_grade_id);
        getline(student_grades, student_grade_grade);
        
        student_list_grades.push_back(Grade(student_grade_course, student_grade_id, student_grade_grade));
    }
    student_grades.close(); 
}

void output_grade_file(string file_name, vector<Grade>& student_list_grades)
{
    ofstream out_file;
    out_file.open(file_name, std::ios_base::app);
     
     for(unsigned int i = 0; i < student_list_grades.size(); i++)
    {
        out_file << student_list_grades[i].get_grade_ID() << "\t";
        out_file << student_list_grades[i].get_grade_grade() << "\t";
        out_file << student_list_grades[i].get_grade_course() << endl;
        
        ///call add grade to student function... school class 
         
    }
        out_file << endl; 
     //out_file.close();
}

void read_query_file( string file_name, vector<string>& student_query_list)
{
    ifstream query_list;
    string student_query_id;
    query_list.open(file_name);
    while(getline(query_list, student_query_id))
    {
        student_query_list.push_back(student_query_id);
    }
    query_list.close();
}

void output_query_file(string file_name, vector<string>& student_query_list, vector<Student>& student_list)
{
    ofstream out_file;
    out_file.open(file_name, std::ios_base::app);
    //float gpa = 0; 
  
  for (unsigned int i = 0; i < student_query_list.size(); i++)  
  {
    for (unsigned int j = 0; j < student_query_list.size(); j++)
    {
        if (student_query_list[i] == student_list[j].get_ID())
        {
            out_file << student_list[j].get_ID();
            out_file << "\t";
            out_file << "\t" <<student_list[j].get_name();
            out_file << endl;
            //out_file << "\t" << fixed << setprecision(2) << setfill('0') << gpa;
        }
    }
  }
    //out_file.close();
}  


/*
void get_gpa (vector<Student>& student_list, map<string,float> gradepoint)
{
    map<string, float> gradepoint;
    gradepoint["A"] = 4.0;
    gradepoint["A-"] = 3.7;
    gradepoint["B+"] = 3.4;
    gradepoint["B"] = 3.0;
    gradepoint["B-"] = 2.7;
    gradepoint["C+"] = 2.4;
    gradepoint["C"] = 2.0;
    gradepoint["C-"] = 1.7; 
    gradepoint["D+"] = 1.4;
    gradepoint["D"] = 1.0;
    gradepoint["D-"] = 0.7;
    gradepoint["E"] = 0.0;
}
*/



int main(int argc,  char* argv[])
{
////////////////////////////////////////
///// MAP ////


/////////////////////////////////////////
//    ofstream out_file;
//    student_grades.open(argv[2]);
//    string line;
//    print (argv[4], student_list, student_list_grades, student_query_list);

    vector<Student> student_list;
    vector<Grade> student_list_grades;    
    vector<string> student_query_list;
    //////////////Reading in the student file, and loading into vector
    
    read_student_info( argv[1], student_list );
    
    //////////////Sorting Student file
    
    sort(student_list.begin(), student_list.end());

    //////////////Outputing Student file
    
    output_student_file( argv[4], student_list );
    
    //////////////Reading in the course file and loading into vector
    
  //  read_course_info ( argv[2], student_list_grades );
    
    //////////////Sorting Grade file
    
   // sort(student_list_grades.begin(), student_list_grades.end());
    
    //////////////Outputing Grade file
    
   // output_grade_file ( argv[4], student_list_grades);
    
    /////////////Reading in the query file and loading into a vector 
    
   // read_query_file(argv[3], student_query_list);
    
    ////////////Outputing the Query file
    
  //  output_query_file (argv[4], student_query_list, student_list );
 


//    out_file.close();

    return 0;
}
