#include "AVL.h"
#include "NodeInterface.h"

    
    NodeInterface * AVL:: getRootNode() const
    {
        return root; 
    }


	bool AVL:: add(int data)
	{
	    add_function( root , data ); 
	    //cout << "add succccc" << endl; 
	}
	
	bool AVL:: add_function(Node *& n, int value)
	{
	    if (n == NULL) // nothing entered yet 
	    {
	        n = new Node(value); 
	        n->height = 1; 
	        return true; 
	    }
	    
	    if ( n->data > value )
	    {
	        bool b = add_function( n->left, value); 
	       // cout << "added left:" << b << "val= " << value; 
	        check_height( n );
	        balance ( n );
	        return b;
	    }
	   
	    if ( n->data < value )
	    {
	        
	        bool b = add_function( n->right, value); 
	        check_height( n );
	        balance ( n );
	        return b;
	    }
	    
	    
	    return false; 
	}
	
    bool AVL:: remove(int data)
    {
        remove_function( root, data );
    }
    
    bool AVL:: remove_function(Node*& n, int value)
    {
        if (n == NULL) // not found 
	    {
	        return false;  
	    }
	    
	    if ( n->data > value )
	    {
	        bool b = remove_function( n->left, value); 
	        check_height(n);
	        balance (n);
	        check_height(n);
	        return b; 
	    }
	   
	    if ( n->data < value )
	    {
	        bool b = remove_function( n->right, value); 
	        check_height( n); 
	        balance ( n);
	        check_height(n);
	        return b; 
	    }
	    //if its not smaller or larger and we know its there it has to be equal to 
	    //removing logic---------------
	    
	    if ( n->right == NULL & n->left == NULL) //no children 
	    {
	        delete n;
	        n = NULL; 
	        return true; 
	    }
	    
	    if ( n->right == NULL || n->left == NULL) // one child 
	    {
	        Node * temp = n->left;
	        if (n->left == NULL)
	        {
	            temp = n->right;
	        }
	        delete n;
	        n = temp; 
	        return true; 
	    }
	    
	    //only case left is 2 children
	    
	    Node * temp = n->left;
	    Node * parent = n; 
	    while ( temp->right != NULL)
	    {
	        parent = temp; 
	        temp = temp->right; 
	    }
	    if (n->data != parent->data)
	    {
	    	parent->right = temp->left;
	    }
	    else
	    {
	    	parent->left = temp->left; 
	    }
	    n->data = temp->data;
	    
	    check_height(parent); 
	    
	    delete temp; 
	    
	   // cout << "Parent: " << parent->data << endl; 
	   // balance ( parent); 
	    
	    check_height( n );
	    
	    balance ( n );
	    check_height(n);
	    return true; 
    }

	void AVL:: clear()
	{
	    clear_function(root);
	    root = NULL; 
	}
	
	void AVL:: clear_function( Node * n)
	{
	    if (n == NULL)
	    {
	        return; 
	    }
	    if (n->left != NULL)
	    {
	        clear_function(n->left); 
	    }
	    if (n->right != NULL)
	    {
	        clear_function(n->right);
	    }
	    
	    delete n; 
	    //n = NULL; 
	}
	
	int AVL:: check_height( Node * n)
	{
	    if ( n == NULL)
	    {
	        return 0; 
	    }
	    
	    int left_height;
	    int right_height; 
	    
	    ///// error checking for if n is the only node or if it doesnt have children 
	    if ( n->left == NULL)
	    {
	        left_height = 0; 
	    }
	    else
	        left_height = n->left->height;
	        
	    if ( n->right == NULL)
	    {
	        right_height = 0; 
	    }
	    else
	        right_height = n->right->height; 
	    
////////////////////////////////////////////////


	    if (left_height > right_height)
	    {
	        left_height++; 
	        n->height = left_height; 
	        return left_height; 
	    }
	    
	    if (right_height > left_height)
	    {
	        right_height++;
	        n->height = right_height; 
	        return right_height; 
	    }
	    
	    else 
	    {
	        right_height++;
	        n->height = right_height; 
	        return right_height; 
	    }
	    
	}
	
	void AVL:: balance (Node *& n)
	{
		if (n == NULL)
			return; 
			
		balance(n->left); 
		balance(n->right);
//////////////////////
	    int left_height;
	    int right_height; 
	    
	    ///// error checking for if n is the only node or if it doesnt have children 
	    if ( n->left == NULL)
	    {
	        left_height = 0; 
	    }
	    else
	        left_height = n->left->height;
	        
	    if ( n->right == NULL)
	    {
	        right_height = 0; 
	    }
	    else
	        right_height = n->right->height; 
	        
	   //////////////////////////////////////////////////////
	   
	    if ( (right_height - left_height )  > 1 )
	    {
	        if ( heavy_side( n->right) == -1 )
	        {
	        //	cout << "right_rotation" << endl; 
	            right_rotation( n->right); 
	        }
	        
	       left_rotation(n); 
		//	cout << "left_rotation" << endl; 
	    }
	    
	    if ( (right_height - left_height )  < -1 )
	    {
	        if ( heavy_side( n->left) == 1 )
	        {
	        //	cout << "left_rotation" << endl; 
	            left_rotation( n->left); 
	        }
	        
	       right_rotation(n); 
	       //cout << "right_rotation" << endl; 
	    }
	}
	void AVL:: right_rotation (Node *& n)
	{
	    Node * temp = n->left->right; 
	    n->left->right = n;
	    n = n->left; 
	    n->right->left = temp; 
	    
	    check_height(n->right);
	    check_height(n); 
	}
	void AVL:: left_rotation (Node *& n)
	{
	    Node * temp = n->right->left;
	    n->right->left = n; 
	    n = n->right; 
	    n->left->right = temp; 
	    
	    check_height( n->left);
	    check_height(n); 
	}
	
	int AVL:: heavy_side(Node * n)
	{
	    int left_height;
	    int right_height; 
	    
	    ///// error checking for if n is the only node or if it doesnt have children 
	    if ( n->left == NULL)
	    {
	        left_height = 0; 
	    }
	    else
	        left_height = n->left->height;
	        
	    if ( n->right == NULL)
	    {
	        right_height = 0; 
	    }
	    else
	        right_height = n->right->height; 
	    ////////////////////////////////////////////
	    
	    if ( left_height > right_height )
	        return -1; 
	   
	   if ( left_height < right_height )
	        return 1; 
	        
	   return 0; 
	}