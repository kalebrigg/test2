#include "Spell_Checker.h"
using namespace std;

Spell_Checker:: Spell_Checker()
{
    string word = "";
}

void Spell_Checker:: read_dictionary(string file_name)
{
    ifstream dictionary_file;
    string word;
    
    dictionary_file.open(file_name);
    
    while (dictionary_file >> word)
    {
        word = make_lower_case(word);
        dictionary.insert(word);
    }
    
    dictionary_file.close();
    
}

string Spell_Checker:: make_lower_case(string word)
{
    for (unsigned int i = 0; i < word.size(); i++)
    {
        if (isupper(word[i]))
        {
            word[i] = tolower(word[i]);
        }
    }
    return word;
}

void Spell_Checker:: read_document(string file_name)
{
    int line = 0; 
    string sentence;
    ifstream document_file;
    document_file.open(file_name);
    
    while (getline(document_file, sentence))
    {
        sentence = make_alpha(sentence);
        //cout << sentence << endl; 
        
        line++;
        stringstream ss(sentence);
        while (ss >> word)
        {
            if(find_word(word) == false)
            {
                misspelled_words[word].push_back(line);
            }
        }
    }
    document_file.close();
    
}

string Spell_Checker:: make_alpha(string word)
{
    for (unsigned int i = 0; i < word.size(); i++)
    {
        if (!isalpha(word[i]))
        {
            word[i] = ' ';
            //return " ";
        }
        else
        {
            word[i] = tolower(word[i]);
        }
    }
    return word;
}

bool Spell_Checker:: find_word(string word)
{
    unsigned int i = 0; 
    
     if (dictionary.count(word) > i)
     {
         return true;
     }
     else
     {
         return false; 
     }
     
      
    
}


void Spell_Checker:: print_dictionary()
{
    set<string>::iterator iter;
     
    for (iter = dictionary.begin(); iter != dictionary.end(); iter++)
    {
        cout << (*iter) << endl; 
    }
}

void Spell_Checker:: print_output(string file_name)
{
    ofstream out_file;
    out_file.open(file_name);
    
    for(auto p: misspelled_words)
    {
        out_file << p.first << ": ";
        for(unsigned int i = 0; i < p.second.size(); i++)
        {
            out_file << p.second[i] << " ";
        }
        out_file << endl; 
    }
}




    
    
    
    
    
    
    /*ifstream dictionary_in;
    string word;
    
    dictionary_in.open(file_name);
    while(dictionary_in >> word)
    {
        for (int i = 0; i < word.size(); i++)
        {
            isalpha(word[i]);
            
            
            if (islower(word[i]))
            {
                word += word[i];
                cout << "word: " << word << endl; 
            }
            if (isupper(c))
            {
                word += tolower(c);
                cout << "word: " << word << endl; 
            }
            if (isspace(c))
            {
                
                dictionary.insert(word);
                cout << "word" << word << endl; 
                word = "";
            }
        }
    }*/