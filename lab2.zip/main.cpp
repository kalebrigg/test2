
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <stdio.h>
#include <ctype.h>
#include <map>
#include <set>
#include "Spell_Checker.h"
 
using namespace std;

/*
void read_dictionary(string file_name, set<string>& dictionary)
{
    ifstream dictionary_in;
    string word[]=""; 
    
    dictionary_in.open(file_name);
    while(dictionary_in >> word)
    {
        for (int i = 0; i < word.length(); i++)
        {
            char c = word[i];
            if (isupper(c))
            {
                tolower(c);
                dictionary.insert(c);
            }
            else
            {
                dictionary.insert(c);
            }
        }
        
    
    }
    dictionary_in.close();
    
    
}
*/
/*
void output_dictionary_file(string file_name,set<string> dictionary)
{
    ofstream out_file;
    out_file.open(file_name, std::ios_base::app);
    
    for (unsigned int i = 0; i < dictionary.size(); i++)
    {
        outfile << dictionary[i] << endl;
        
    }
    out_file <<endl;
}
*/
int main(int argc,  char* argv[])
{
    
    
    /////////////Read Dictionary File, Edit, & Add to Set 
    Spell_Checker sp;
    sp.read_dictionary(argv[1]);
    sp.read_document(argv[2]);
    //check to see if dictionary is working sp.print_dictionary(); 
    sp.print_output(argv[3]);
    /////////////Read Document File, Edit, & Add to Map
return 0;
}