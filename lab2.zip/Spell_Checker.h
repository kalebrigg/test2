#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <set>
#include <map>
#include <sstream>

using namespace std;

class Spell_Checker
{
    private:
        set<string> dictionary;
        map<string, vector<int>> misspelled_words;
        string word; 

    public:
        Spell_Checker();
        
        void read_dictionary(string file_name);
        string make_lower_case(string word);
        
        void read_document(string file_name);
        string make_alpha(string word);
        
        bool find_word(string word); 
        
        void print_output(string file_name);
        void print_dictionary();
};


